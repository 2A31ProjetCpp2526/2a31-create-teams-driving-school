#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include "connection.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Établir la connexion avec Singleton
    Connection* conn = Connection::getInstance();
    bool test = conn->createConnect();

    MainWindow w;

    if(test) {
        w.show();
        QMessageBox::information(nullptr, "Connexion", "Base de données connectée avec succès!");
    }
    else {
        QMessageBox::critical(nullptr, "Erreur", "Échec de connexion à la base de données!");
        return -1;
    }

    return a.exec();
}
