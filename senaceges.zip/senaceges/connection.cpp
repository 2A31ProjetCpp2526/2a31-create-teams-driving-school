#include "connection.h"
#include <QDebug>

// Initialisation du pointeur static
Connection* Connection::instance = nullptr;

Connection::Connection()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("gestion_seances.db");
}

Connection* Connection::getInstance()
{
    if (instance == nullptr) {
        instance = new Connection();
    }
    return instance;
}

bool Connection::createConnect()
{
    if (!db.open()) {
        qDebug() << "Erreur connexion:" << db.lastError().text();
        return false;
    }
    qDebug() << "Connexion réussie!";
    return true;
}

QSqlDatabase Connection::getDatabase()
{
    return db;
}
