#ifndef SEANCE_H
#define SEANCE_H

#include <QString>
#include <QDate>
#include <QTime>
#include <QSqlQuery>
#include <QSqlQueryModel>

class Seance
{
private:
    int id_seance;
    QDate date;
    QTime heure_debut;
    int duree;
    QString type;
    QString appareil;

public:
    // Constructeurs
    Seance();
    Seance(int id, QDate date, QTime heure, int duree, QString type, QString appareil);

    // Getters
    int getId() const { return id_seance; }
    QDate getDate() const { return date; }
    QTime getHeureDebut() const { return heure_debut; }
    int getDuree() const { return duree; }
    QString getType() const { return type; }
    QString getAppareil() const { return appareil; }

    // Setters
    void setId(int id) { id_seance = id; }
    void setDate(QDate d) { date = d; }
    void setHeureDebut(QTime h) { heure_debut = h; }
    void setDuree(int d) { duree = d; }
    void setType(QString t) { type = t; }
    void setAppareil(QString a) { appareil = a; }

    // Méthodes CRUD
    bool ajouter();
    bool modifier();
    bool supprimer(int id);
    static QSqlQueryModel* afficher();
    static QSqlQueryModel* rechercher(const QString& critere);
};

#endif // SEANCE_H
