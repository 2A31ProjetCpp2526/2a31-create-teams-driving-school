#include "connection.h"
#include <QDebug>

// Initialisation du pointeur static
Connection* Connection::instance = nullptr;

Connection::Connection()
{
    db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("drivingschool");
    db.setUserName("drivingschool");//inserer nom de l'utilisateur
    db.setPassword("123456");//inserer mot de passe de cet utilisateur
}

Connection* Connection::getInstance()
{
    if (instance == nullptr) {
        instance = new Connection();
    }
    return instance;
}

bool Connection::createConnect()
{
    if (!db.open()) {
        qDebug() << "Erreur connexion:" << db.lastError().text();
        return false;
    }
    qDebug() << "Connexion réussie!";
    return true;
}

QSqlDatabase Connection::getDatabase()
{
    return db;
}

