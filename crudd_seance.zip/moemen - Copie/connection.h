#ifndef CONNECTION_H
#define CONNECTION_H

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

class Connection
{
private:
    static Connection* instance;
    QSqlDatabase db;

    // Constructeur privé
    Connection();

public:
    // Supprimer les opérations de copie
    Connection(const Connection&) = delete;
    Connection& operator=(const Connection&) = delete;

    // Méthode pour obtenir l'instance unique
    static Connection* getInstance();

    // Méthode pour établir la connexion
    bool createConnect();

    // Getter pour la base de données
    QSqlDatabase getDatabase();
};

#endif // CONNECTION_H
