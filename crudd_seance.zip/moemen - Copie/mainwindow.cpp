#include "mainwindow.h"
#include "seance.h"
#include "ui_mainwindow.h"
#include "connection.h"
#include <QWidget>
#include <QLabel>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Connexions pour la navigation entre pages
    connect(ui->seance, &QPushButton::clicked, this, &MainWindow::seanceclick);
    connect(ui->employe, &QPushButton::clicked, this, &MainWindow::employeclick);
    connect(ui->client, &QPushButton::clicked, this, &MainWindow::clientclick);
    connect(ui->vehicule, &QPushButton::clicked, this, &MainWindow::vehiculeclick);
    connect(ui->contrat, &QPushButton::clicked, this, &MainWindow::contratclick);

    connect(ui->client, &QPushButton::clicked, this, &MainWindow::clientclick);
    connect(ui->vehicule, &QPushButton::clicked, this, &MainWindow::vehiculeclick);
    connect(ui->contrat, &QPushButton::clicked, this, &MainWindow::contratclick);

    // Initialisation de la base de données et de la table des séances
    Connection* conn = Connection::getInstance();
    if (conn->createConnect()) {
        QSqlQuery query;
        query.exec("CREATE TABLE IF NOT EXISTS seances ("
                   "id_seance INTEGER PRIMARY KEY, "
                   "date DATE, "
                   "heure_debut TIME, "
                   "duree INTEGER, "
                   "type VARCHAR(50), "
                   "appareil VARCHAR(50))");

        refreshTable();
    } else {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données échouée!");
    }

    // Configuration des pages (garder votre code existant)
    for (int i = 1; i <= 4; ++i) {
        QWidget *page = new QWidget();
        QLabel *label = new QLabel("Page " + QString::number(i) + " - Contenu à ajouter", page);
        label->setGeometry(100, 100, 300, 50);
        ui->stack->addWidget(page);
    }

    ui->stack->setCurrentIndex(0);
}

void MainWindow::seanceclick() {
    ui->stack->setCurrentIndex(0);
    refreshTable(); // Rafraîchir la table quand on clique sur séance
}

void MainWindow::employeclick() { ui->stack->setCurrentIndex(1); }
void MainWindow::clientclick() { ui->stack->setCurrentIndex(2); }
void MainWindow::vehiculeclick() { ui->stack->setCurrentIndex(3); }
void MainWindow::contratclick() { ui->stack->setCurrentIndex(4); }

void MainWindow::refreshTable()
{
    QSqlQueryModel *model = Seance::afficher();
    ui->tableView_seances->setModel(model);
}

void MainWindow::clearFields()
{
    ui->lineEdit_id->clear();
    ui->dateEdit_date->setDate(QDate::currentDate());
    ui->timeEdit_heure->setTime(QTime::currentTime());
    ui->lineEdit_duree->clear();
    ui->comboBox_type->setCurrentIndex(0);
    ui->lineEdit_appareil->clear();
}

void MainWindow::on_pushButton_valider_clicked()
{
    int id = ui->lineEdit_id->text().toInt();
    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();

    if (id <= 0 || duree <= 0 || appareil.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Veuillez remplir tous les champs correctement!");
        return;
    }

    Seance seance(id, date, heure, duree, type, appareil);

    if (seance.ajouter()) {
        QMessageBox::information(this, "Succès", "Séance ajoutée avec succès!");
        refreshTable();
        clearFields();
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de l'ajout!");
    }
}

void MainWindow::on_pushButton_modifier_clicked()
{
    int id = ui->lineEdit_id->text().toInt();
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner une séance à modifier!");
        return;
    }

    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();

    Seance seance(id, date, heure, duree, type, appareil);

    if (seance.modifier()) {
        QMessageBox::information(this, "Succès", "Séance modifiée avec succès!");
        refreshTable();
        clearFields();
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de la modification!");
    }
}

void MainWindow::on_pushButton_supprimer_clicked()
{
    int id = ui->lineEdit_id->text().toInt();

    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner une séance à supprimer!");
        return;
    }

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation",
                                  "Voulez-vous vraiment supprimer cette séance?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        Seance seance;
        if (seance.supprimer(id)) {
            QMessageBox::information(this, "Succès", "Séance supprimée avec succès!");
            refreshTable();
            clearFields();
        } else {
            QMessageBox::critical(this, "Erreur", "Erreur lors de la suppression!");
        }
    }
}

void MainWindow::on_pushButton_recherche_clicked()
{
    QString critere = ui->lineEdit_recherche->text();
    QSqlQueryModel *model;

    if (!critere.isEmpty()) {
        model = Seance::rechercher(critere);
    } else {
        model = Seance::afficher();
    }

    ui->tableView_seances->setModel(model);
}

void MainWindow::on_tableView_seances_clicked(const QModelIndex &index)
{
    int id = index.sibling(index.row(), 0).data().toInt();
    QDate date = index.sibling(index.row(), 1).data().toDate();
    QTime heure = index.sibling(index.row(), 2).data().toTime();
    int duree = index.sibling(index.row(), 3).data().toInt();
    QString type = index.sibling(index.row(), 4).data().toString();
    QString appareil = index.sibling(index.row(), 5).data().toString();

    ui->lineEdit_id->setText(QString::number(id));
    ui->dateEdit_date->setDate(date);
    ui->timeEdit_heure->setTime(heure);
    ui->lineEdit_duree->setText(QString::number(duree));

    int indexType = ui->comboBox_type->findText(type);
    if (indexType != -1) {
        ui->comboBox_type->setCurrentIndex(indexType);
    }

    ui->lineEdit_appareil->setText(appareil);
}

MainWindow::~MainWindow()
{
    delete ui;
}
