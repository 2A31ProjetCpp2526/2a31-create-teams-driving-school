#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QDate>
#include <QSqlQueryModel>  // ✅ AJOUTER CETTE LIGNE
QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // Navigation
    void seanceclick();
    void employeclick();
    void clientclick();
    void vehiculeclick();
    void contratclick();
    void calendrierclick();

    // Séances
    void on_pushButton_valider_clicked();
    void on_pushButton_modifier_clicked();
    void on_pushButton_supprimer_clicked();
    void on_pushButton_recherche_clicked();
    void on_comboBox_trier_currentTextChanged(const QString &text);
    void on_pushButton_effacer_clicked();
    void on_pushButton_rafraichir_clicked();
     void on_pushButton_export_clicked();  // Export PDF
    void on_pushButton_statistiques_clicked();
    void on_tableView_seances_clicked(const QModelIndex &index);
    void on_pushButton_envoyer_clicked();


    // Calendrier
    void onCalendrierDateClicked(const QDate &date);
    void onMoisPrecedent();
    void onMoisSuivant();
    void onAfficherCalendrier();

private:
    Ui::MainWindow *ui;
    void refreshTable();
    void clearFields();

    // Calendrier
    void setupCalendrier();
    void updateCalendrier();
    void afficherDetailsDate(const QDate &date);
    void marquerDatesAvecSeances();

    QDate m_dateCalendrier;
    QMap<QDate, int> m_seancesParDate;
     QString genererHTMLFromModel(QSqlQueryModel* model);
};

#endif // MAINWINDOW_H
