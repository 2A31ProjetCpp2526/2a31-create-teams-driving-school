#include "mainwindow.h"
#include "seance.h"
#include "ui_mainwindow.h"
#include "connection.h"
#include <QWidget>
#include <QLabel>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QTextDocument>
#include <QFileDialog>
#include <QPainter>
#include <QPdfWriter>
#include <QDir>
#include <QPageSize>
#include <QPushButton>
#include <QGridLayout>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTextEdit>
#include <QDialog>
#include <QSqlRecord>
#include <QList>
#include <QPrinter>
#include <QTextDocument>
#include <QDesktopServices>
#include <QFileDialog>
#include <QtCharts/QPieSeries>
#include <QtCharts/QPieSlice>
#include <QtCharts/QChartView>
#include <QtCharts/QChart>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Connexions boutons de navigation
    connect(ui->seance, &QPushButton::clicked, this, &MainWindow::seanceclick);
    connect(ui->employe, &QPushButton::clicked, this, &MainWindow::employeclick);
    connect(ui->client, &QPushButton::clicked, this, &MainWindow::clientclick);
    connect(ui->vehicule, &QPushButton::clicked, this, &MainWindow::vehiculeclick);
    connect(ui->contrat, &QPushButton::clicked, this, &MainWindow::contratclick);
    connect(ui->calendrier, &QPushButton::clicked, this, &MainWindow::calendrierclick);

    // Connexion ComboBox trier
    connect(ui->comboBox_trier, &QComboBox::currentTextChanged,
            this, &MainWindow::on_comboBox_trier_currentTextChanged);

    // Connexion à la base
    Connection c;
    if (c.createConnect()) {
        qDebug() << "✅ Base connectée via ODBC.";
        refreshTable();
    } else {
        QMessageBox::critical(this, "Erreur", "❌ Connexion à la base de données échouée !");
    }

    // Initialiser le calendrier
    setupCalendrier();

    ui->stack->setCurrentIndex(0);
}

void MainWindow::seanceclick()
{
    ui->stack->setCurrentIndex(0);
    refreshTable();
}

void MainWindow::employeclick() { ui->stack->setCurrentIndex(1); }
void MainWindow::clientclick()   { ui->stack->setCurrentIndex(2); }
void MainWindow::vehiculeclick() { ui->stack->setCurrentIndex(3); }
void MainWindow::contratclick()  { ui->stack->setCurrentIndex(4); }
void MainWindow::calendrierclick() {
    ui->stack->setCurrentIndex(5);
    updateCalendrier();
}

void MainWindow::refreshTable()
{
    QSqlQueryModel *model = Seance::afficher();
    ui->tableView_seances->setModel(model);
    ui->tableView_seances->resizeColumnsToContents();
}

void MainWindow::clearFields()
{
    ui->lineEdit_id->clear();
    ui->dateEdit_date->setDate(QDate::currentDate());
    ui->timeEdit_heure->setTime(QTime::currentTime());
    ui->lineEdit_duree->clear();
    ui->comboBox_type->setCurrentIndex(0);
    ui->lineEdit_appareil->clear();
    ui->lineEdit_id_client->clear();
    ui->lineEdit_immatricule->clear();
    ui->lineEdit_id_moniteur->clear();
    ui->lineEdit_recherche->clear();
}

void MainWindow::on_pushButton_valider_clicked()
{
    qDebug() << "=== BOUTON VALIDER CLIQUE ===";

    int id = ui->lineEdit_id->text().toInt();
    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();
    int id_client = ui->lineEdit_id_client->text().toInt();
    QString immatricule = ui->lineEdit_immatricule->text();
    int id_moniteur = ui->lineEdit_id_moniteur->text().toInt();

    // Validation des champs
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ L'ID doit être supérieur à 0 !");
        return;
    }
    if (duree <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ La durée doit être supérieure à 0 !");
        return;
    }
    if (appareil.isEmpty()) {
        QMessageBox::warning(this, "Attention", "⚠️ L'appareil ne peut pas être vide !");
        return;
    }
    if (id_client <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ L'ID client doit être supérieur à 0 !");
        return;
    }
    if (immatricule.isEmpty()) {
        QMessageBox::warning(this, "Attention", "⚠️ L'immatricule ne peut pas être vide !");
        return;
    }
    if (id_moniteur <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ L'ID moniteur doit être supérieur à 0 !");
        return;
    }

    // Vérification si l'ID existe déjà
    if (Seance::existeDeja(id)) {
        QMessageBox::warning(this, "Attention", "❌ Cet ID existe déjà ! Veuillez utiliser un ID différent.");
        return;
    }

    Seance seance(id, date, heure, duree, type, appareil, id_client, immatricule, id_moniteur);

    if (seance.ajouter()) {
        QMessageBox::information(this, "Succès", "✅ Séance ajoutée avec succès !");
        refreshTable();
        clearFields();
        updateCalendrier();
    } else {
        QMessageBox::critical(this, "Erreur", "❌ Erreur lors de l'ajout !");
    }
}

void MainWindow::on_pushButton_modifier_clicked()
{
    qDebug() << "=== BOUTON MODIFIER CLIQUE ===";

    int id = ui->lineEdit_id->text().toInt();
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez sélectionner une séance à modifier !");
        return;
    }

    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();
    int id_client = ui->lineEdit_id_client->text().toInt();
    QString immatricule = ui->lineEdit_immatricule->text();
    int id_moniteur = ui->lineEdit_id_moniteur->text().toInt();

    // Validation des champs
    if (duree <= 0 || appareil.isEmpty() || id_client <= 0 || immatricule.isEmpty() || id_moniteur <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez remplir tous les champs correctement !");
        return;
    }

    Seance seance(id, date, heure, duree, type, appareil, id_client, immatricule, id_moniteur);

    if (seance.modifier()) {
        QMessageBox::information(this, "Succès", "✅ Séance modifiée avec succès !");
        refreshTable();
        clearFields();
        updateCalendrier();
    } else {
        QMessageBox::critical(this, "Erreur", "❌ Erreur lors de la modification !");
    }
}

void MainWindow::on_pushButton_supprimer_clicked()
{
    qDebug() << "=== BOUTON SUPPRIMER CLIQUE ===";

    int id = ui->lineEdit_id->text().toInt();

    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez sélectionner une séance à supprimer !");
        return;
    }

    if (QMessageBox::question(this, "Confirmation",
                              "Voulez-vous vraiment supprimer la séance ID " + QString::number(id) + " ?",
                              QMessageBox::Yes | QMessageBox::No)
        == QMessageBox::Yes)
    {
        Seance s;
        if (s.supprimer(id)) {
            QMessageBox::information(this, "Succès", "✅ Séance supprimée avec succès !");
            refreshTable();
            clearFields();
            updateCalendrier();
        } else {
            QMessageBox::critical(this, "Erreur", "❌ Erreur lors de la suppression !");
        }
    }
}

void MainWindow::on_pushButton_recherche_clicked()
{
    QString critere = ui->lineEdit_recherche->text();
    QSqlQueryModel *model;

    if (!critere.isEmpty()) {
        model = Seance::rechercher(critere);
        if (model->rowCount() == 0) {
            QMessageBox::information(this, "Recherche", "Aucune séance trouvée pour: " + critere);
        }
    } else {
        model = Seance::afficher();
    }

    ui->tableView_seances->setModel(model);
}

void MainWindow::on_comboBox_trier_currentTextChanged(const QString &text)
{
    if (text.isEmpty()) {
        qDebug() << "⚠️ Texte vide dans le comboBox";
        return;
    }

    qDebug() << "🎯 Tri demandé:" << text;

    // Utiliser directement le texte du ComboBox
    QSqlQueryModel* model = Seance::trier(text);

    if (model) {
        ui->tableView_seances->setModel(model);
        qDebug() << "✅ Modèle appliqué au tableView";

        // Message de statut
        statusBar()->showMessage("Trié par: " + text, 3000);
    } else {
        qDebug() << "❌ Modèle null après tri";
    }
}

void MainWindow::on_pushButton_effacer_clicked()
{
    clearFields();
}

void MainWindow::on_pushButton_rafraichir_clicked()
{
    refreshTable();
}


void MainWindow::on_pushButton_export_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this,
                                                    "Exporter les séances en PDF",
                                                    QDir::homePath() + "/liste_seances.pdf",
                                                    "Fichiers PDF (*.pdf)");

    if (fileName.isEmpty()) return;

    if (!fileName.endsWith(".pdf", Qt::CaseInsensitive)) {
        fileName += ".pdf";
    }

    // Récupérer le modèle actuel (avec tri/recherche appliqué)
    QSqlQueryModel* model = qobject_cast<QSqlQueryModel*>(ui->tableView_seances->model());

    if (!model || model->rowCount() == 0) {
        QMessageBox::information(this, "Export PDF", "Aucune séance à exporter !");
        return;
    }

    // Générer le HTML à partir du modèle
    QString html = genererHTMLFromModel(model);

    QTextDocument document;
    document.setHtml(html);

    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName(fileName);
    printer.setPageSize(QPageSize(QPageSize::A4));
    //printer.setPageOrientation(QPageSize::Landscape);
    printer.setPageMargins(QMarginsF(10, 10, 10, 10));

    document.print(&printer);

    QMessageBox::information(this, "✅ Succès",
                             QString("PDF exporté!\n\nFichier: %1\nSéances: %2").arg(fileName).arg(model->rowCount()));
}

QString MainWindow::genererHTMLFromModel(QSqlQueryModel* model)
{
    QString html = R"(
    <html>
    <head>
    <style>
        body { font-family: Arial, sans-serif; margin: 15px; }
        h1 { color: #2c3e50; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th { background-color: #3498db; color: white; padding: 10px; }
        td { padding: 8px; border-bottom: 1px solid #ddd; }
        tr:nth-child(even) { background-color: #f9f9f9; }
    </style>
    </head>
    <body>
    <h1>RoadMaster - Séances</h1>
    <table>
    )";

    // En-têtes
    html += "<tr>";
    for (int col = 0; col < model->columnCount(); ++col) {
        QString header = model->headerData(col, Qt::Horizontal).toString();
        html += "<th>" + header + "</th>";
    }
    html += "</tr>";

    // Données
    for (int row = 0; row < model->rowCount(); ++row) {
        html += "<tr>";
        for (int col = 0; col < model->columnCount(); ++col) {
            QModelIndex index = model->index(row, col);
            QString data = model->data(index).toString();
            html += "<td>" + data + "</td>";
        }
        html += "</tr>";
    }

    html += "</table></body></html>";
    return html;
}
void MainWindow::on_pushButton_statistiques_clicked()
{
    // Créer une nouvelle fenêtre pour les statistiques
    QWidget *statsWindow = new QWidget();
    statsWindow->setWindowTitle("🚗 Statistiques des Séances par Type");
    statsWindow->setMinimumSize(900, 700);
    statsWindow->setStyleSheet("background-color: #f8f9fa;");

    // Layout principal
    QVBoxLayout *mainLayout = new QVBoxLayout(statsWindow);

    // Titre
    QLabel *title = new QLabel("📊 STATISTIQUES DES SÉANCES PAR TYPE");
    title->setStyleSheet("font-size: 22px; font-weight: bold; color: #2c3e50; padding: 20px; background-color: white; border-radius: 10px; margin: 10px;");
    title->setAlignment(Qt::AlignCenter);
    mainLayout->addWidget(title);

    // Récupérer les statistiques
    QMap<QString, int> stats = Seance::getStatistiquesParType();
    int total = 0;
    for (int count : stats) {
        total += count;
    }

    if (total == 0) {
        QLabel *noDataLabel = new QLabel("Aucune séance dans la base de données !");
        noDataLabel->setStyleSheet("font-size: 18px; color: #7f8c8d; padding: 50px; background-color: white; border-radius: 10px; margin: 10px;");
        noDataLabel->setAlignment(Qt::AlignCenter);
        mainLayout->addWidget(noDataLabel);
    } else {
        // Widget pour graphique + légende
        QHBoxLayout *chartLayout = new QHBoxLayout();

        // ==================== CAMEMBERT ====================
        QPieSeries *series = new QPieSeries();

        // Couleurs pour les types de séances
        QList<QColor> couleurs = {
            QColor(41, 128, 185),   // Bleu - Conduite
            QColor(39, 174, 96),    // Vert - Code
            QColor(231, 76, 60),    // Rouge - Examen
            QColor(155, 89, 182),   // Violet - Perfectionnement
            QColor(243, 156, 18),   // Orange - Recyclage
            QColor(52, 73, 94)      // Gris foncé - Autre
        };

        int colorIndex = 0;
        for (auto it = stats.begin(); it != stats.end(); ++it) {
            QString type = it.key();
            int count = it.value();
            double percentage = (count * 100.0) / total;

            // Créer la tranche
            QPieSlice *slice = series->append(type, count);
            slice->setColor(couleurs[colorIndex % couleurs.size()]);
            slice->setLabelVisible(true);
            slice->setExploded(false);

            // Formater le label
            QString label = QString("%1\n%2 séances\n%3%")
                                .arg(type)
                                .arg(count)
                                .arg(QString::number(percentage, 'f', 1));
            slice->setLabel(label);
            slice->setLabelArmLengthFactor(0.1);

            colorIndex++;
        }

        // Configurer le graphique
        QChart *chart = new QChart();
        chart->addSeries(series);
        chart->setTitle("Répartition des Séances par Type");
        chart->setTitleFont(QFont("Arial", 14, QFont::Bold));
        chart->setAnimationOptions(QChart::AllAnimations);
        chart->setBackgroundBrush(QBrush(QColor(248, 249, 250)));
        chart->legend()->setVisible(false); // On cache la légende car on va la créer manuellement

        QChartView *chartView = new QChartView(chart);
        chartView->setRenderHint(QPainter::Antialiasing);
        chartView->setFixedSize(500, 400);

        // ==================== LÉGENDE DÉTAILLÉE ====================
        QWidget *legendWidget = new QWidget();
        legendWidget->setFixedWidth(300);
        QVBoxLayout *legendLayout = new QVBoxLayout(legendWidget);

        QLabel *legendTitle = new QLabel("📋 DÉTAIL PAR TYPE");
        legendTitle->setStyleSheet("font-size: 16px; font-weight: bold; color: #2c3e50; padding: 10px;");
        legendLayout->addWidget(legendTitle);

        colorIndex = 0;
        for (auto it = stats.begin(); it != stats.end(); ++it) {
            QString type = it.key();
            int count = it.value();
            double percentage = (count * 100.0) / total;

            QHBoxLayout *itemLayout = new QHBoxLayout();

            // Carré de couleur
            QLabel *colorLabel = new QLabel();
            colorLabel->setFixedSize(20, 20);
            colorLabel->setStyleSheet(QString("background-color: %1; border-radius: 3px; border: 1px solid #ddd;")
                                          .arg(couleurs[colorIndex % couleurs.size()].name()));

            // Texte détaillé
            QLabel *textLabel = new QLabel(
                QString("<b>%1</b><br>%2 séances (%3%)")
                    .arg(type)
                    .arg(count)
                    .arg(QString::number(percentage, 'f', 1))
                );
            textLabel->setStyleSheet("font-size: 12px; color: #2c3e50;");
            textLabel->setWordWrap(true);

            itemLayout->addWidget(colorLabel);
            itemLayout->addWidget(textLabel);
            itemLayout->addStretch();

            legendLayout->addLayout(itemLayout);
            colorIndex++;
        }

        // Ajouter graphique et légende au layout horizontal
        chartLayout->addWidget(chartView);
        chartLayout->addWidget(legendWidget);

        mainLayout->addLayout(chartLayout);

        // ==================== STATISTIQUES GÉNÉRALES ====================
        QLabel *totalLabel = new QLabel(
            QString("📈 TOTAL GÉNÉRAL: <b>%1 séances</b> réparties sur <b>%2 types</b> différents")
                .arg(total)
                .arg(stats.size())
            );
        totalLabel->setStyleSheet("font-size: 16px; color: #27ae60; background-color: white; padding: 15px; border-radius: 10px; margin: 10px;");
        totalLabel->setAlignment(Qt::AlignCenter);
        mainLayout->addWidget(totalLabel);
    }

    // ==================== BOUTON FERMER ====================
    QPushButton *closeButton = new QPushButton("🗙 Fermer");
    closeButton->setFixedSize(120, 45);
    closeButton->setStyleSheet(
        "QPushButton {"
        "background-color: #e74c3c;"
        "color: white;"
        "border: none;"
        "border-radius: 8px;"
        "font-size: 14px;"
        "font-weight: bold;"
        "padding: 10px;"
        "}"
        "QPushButton:hover {"
        "background-color: #c0392b;"
        "}"
        );
    connect(closeButton, &QPushButton::clicked, statsWindow, &QWidget::close);

    mainLayout->addWidget(closeButton, 0, Qt::AlignCenter);

    // Afficher la fenêtre
    statsWindow->show();
}

void MainWindow::on_tableView_seances_clicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    int id = index.sibling(index.row(), 0).data().toInt();
    QString immatricule = index.sibling(index.row(), 1).data().toString();
    int id_client = index.sibling(index.row(), 2).data().toInt();
    int id_moniteur = index.sibling(index.row(), 3).data().toInt();
    QDate date = index.sibling(index.row(), 4).data().toDate();
    QString heure_str = index.sibling(index.row(), 5).data().toString();
    QString type = index.sibling(index.row(), 6).data().toString();
    QString appareil = index.sibling(index.row(), 7).data().toString();
    int duree = index.sibling(index.row(), 8).data().toInt();

    QTime heure = QTime::fromString(heure_str, "HH:mm");

    ui->lineEdit_id->setText(QString::number(id));
    ui->dateEdit_date->setDate(date);
    ui->timeEdit_heure->setTime(heure);
    ui->lineEdit_duree->setText(QString::number(duree));

    int indexType = ui->comboBox_type->findText(type);
    if (indexType != -1)
        ui->comboBox_type->setCurrentIndex(indexType);

    ui->lineEdit_appareil->setText(appareil);
    ui->lineEdit_id_client->setText(QString::number(id_client));
    ui->lineEdit_immatricule->setText(immatricule);
    ui->lineEdit_id_moniteur->setText(QString::number(id_moniteur));
}

void MainWindow::on_pushButton_envoyer_clicked()
{
    qDebug() << "=== BOUTON ENVOYER RAPPEL CLIQUE ===";

    int idSeance = ui->lineEdit_id_2->text().toInt();

    if (idSeance <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez sélectionner une séance à rappeler !");
        return;
    }

    qDebug() << "ID Séance saisi:" << idSeance;

    // VÉRIFICATION RAPIDE DE LA SÉANCE
    QSqlQuery checkQuery;
    checkQuery.prepare("SELECT COUNT(*) FROM SEANCE WHERE ID_SEANCE = :id");
    checkQuery.bindValue(":id", idSeance);

    if (!checkQuery.exec() || !checkQuery.next() || checkQuery.value(0).toInt() == 0) {
        QMessageBox::warning(this, "Erreur", "❌ Cette séance n'existe pas !");
        return;
    }

    /// RÉCUPÉRATION DES INFOS POUR CONFIRMATION - CORRECTION: COLUMN8 et NOM_CLIENT/PRENOM_CLIENT
    QSqlQuery query;
    query.prepare("SELECT s.ID_CLIENT, s.DATE_SEANCE, s.HEURE_DEBUT, c.NOM_CLIENT, c.PRENOM_CLIENT, c.COLUMN8 as EMAIL "
                  "FROM SEANCE s "
                  "LEFT JOIN CLIENT c ON s.ID_CLIENT = c.ID_CLIENT "
                  "WHERE s.ID_SEANCE = :id");
    query.bindValue(":id", idSeance);

    int idClient = 0;
    QString clientInfo = "Client inconnu";
    QString dateInfo = "Date inconnue";
    QString email = "Email non trouvé";

    if (query.exec()) {
        if (query.next()) {
            idClient = query.value("ID_CLIENT").toInt();

            // Vérifier si le client existe dans la jointure
            if (query.value("NOM_CLIENT").isNull()) {
                qDebug() << "❌ Client non trouvé pour ID:" << idClient;
                QMessageBox::critical(this, "Erreur",
                                      "❌ Client non trouvé !\n\n"
                                      "ID Client: " + QString::number(idClient) + "\n"
                                                                        "La séance existe mais le client associé n'a pas été trouvé.");
                return;
            }

            QString nom = query.value("NOM_CLIENT").toString();
            QString prenom = query.value("PRENOM_CLIENT").toString();
            email = query.value("EMAIL").toString();

            QDate dateSeance = query.value("DATE_SEANCE").toDate();
            QTime heureSeance = query.value("HEURE_DEBUT").toTime();

            // Construction des infos avec vérifications
            if (!nom.isEmpty() || !prenom.isEmpty()) {
                clientInfo = prenom + " " + nom + " (ID: " + QString::number(idClient) + ")";
            } else {
                clientInfo = "Client ID: " + QString::number(idClient);
            }

            if (dateSeance.isValid() && heureSeance.isValid()) {
                dateInfo = dateSeance.toString("dd/MM/yyyy") + " à " + heureSeance.toString("HH:mm");
            }

            qDebug() << "✅ Infos récupérées - Client:" << clientInfo << "Email:" << email;

            // VÉRIFICATION EMAIL IMMÉDIATE
            if (email.isEmpty() || email.isNull() || email == "(null)" || email == "NULL") {
                qDebug() << "❌ Email vide pour client ID:" << idClient;
                QMessageBox::warning(this, "Email manquant",
                                     "❌ Aucun email trouvé pour le client de cette séance !\n\n"
                                     "ID Client: " + QString::number(idClient) + "\n"
                                                                       "Client: " + clientInfo + "\n\n"
                                                        "Veuillez vérifier que l'email est renseigné dans la table CLIENT (colonne COLUMN8).");
                return;
            }

        } else {
            qDebug() << "❌ Séance non trouvée ID:" << idSeance;
            QMessageBox::critical(this, "Erreur", "❌ Cette séance n'existe pas !");
            return;
        }
    } else {
        qDebug() << "❌ Erreur requête:" << query.lastError().text();
        QMessageBox::critical(this, "Erreur",
                              "❌ Erreur lors de la récupération des données !\n\n"
                              "Détails: " + query.lastError().text());
        return;
    }

    // Si on arrive ici, toutes les vérifications sont passées
    qDebug() << "✅ Toutes les vérifications passées - Email:" << email;

    // VÉRIFICATION EMAIL
    if (email.isEmpty() || email.isNull() || email == "Email non trouvé") {
        QMessageBox::warning(this, "Email manquant",
                             "❌ Aucun email trouvé pour le client de cette séance !\n\n"
                             "ID Client: " + QString::number(idClient) + "\n"
                                                               "Client: " + clientInfo + "\n\n"
                                                "Veuillez vérifier que l'email est renseigné dans la table CLIENT (colonne COLUMN8).");
        return;
    }

    // CONFIRMATION D'ENVOI
    QMessageBox::StandardButton reply = QMessageBox::question(
        this,
        "Confirmation d'envoi",
        QString("Voulez-vous envoyer un rappel pour :\n\n"
                "🔹 ID Séance: %1\n"
                "👤 Client: %2\n"
                "📧 Email: %3\n"
                "📅 Séance: %4\n\n"
                "Un email de rappel sera envoyé au client.").arg(
                QString::number(idSeance),
                clientInfo,
                email,
                dateInfo),
        QMessageBox::Yes | QMessageBox::No
        );

    if (reply == QMessageBox::Yes) {
        QMessageBox::information(this, "Envoi en cours",
                                 "📧 Envoi du rappel email en cours...\n\n"
                                 "Veuillez patienter quelques secondes.");

        if (Seance::envoyerRappelEmail(idSeance)) {
            QMessageBox::information(this, "Succès",
                                     "✅ Rappel envoyé avec succès !\n\n"
                                     "📧 Destinataire: " + email + "\n"
                                                   "👤 Client: " + clientInfo + "\n"
                                                        "📅 Séance: " + dateInfo + "\n\n"
                                                      "Un log a été sauvegardé dans 'emails_log.txt'");
        } else {
            QMessageBox::critical(this, "Erreur",
                                  "❌ Erreur lors de l'envoi du rappel !");
        }
    }
}

// ============================================================================
// CALENDRIER - IMPLÉMENTATION
// ============================================================================

void MainWindow::setupCalendrier()
{
    m_dateCalendrier = QDate::currentDate();

    connect(ui->pushButton_mois_precedent, &QPushButton::clicked, this, &MainWindow::onMoisPrecedent);
    connect(ui->pushButton_mois_suivant, &QPushButton::clicked, this, &MainWindow::onMoisSuivant);
    connect(ui->pushButton_rafraichir_calendrier, &QPushButton::clicked, this, &MainWindow::onAfficherCalendrier);

    updateCalendrier();
}

void MainWindow::updateCalendrier()
{
    QString moisAnnee = m_dateCalendrier.toString("MMMM yyyy");
    ui->label_mois_annee->setText(moisAnnee);

    marquerDatesAvecSeances();

    QLayoutItem* child;
    while ((child = ui->gridLayout_calendrier->takeAt(0)) != nullptr) {
        if (child->widget()) {
            delete child->widget();
        }
        delete child;
    }

    QStringList jours = {"Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"};
    for (int i = 0; i < 7; ++i) {
        QLabel* label = new QLabel(jours[i]);
        label->setAlignment(Qt::AlignCenter);
        label->setStyleSheet("QLabel { background-color: #3498db; color: white; font-weight: bold; padding: 10px; border: 1px solid #2980b9; border-radius: 5px; }");
        ui->gridLayout_calendrier->addWidget(label, 0, i);
    }

    QDate premierJour(m_dateCalendrier.year(), m_dateCalendrier.month(), 1);
    int jourSemaine = premierJour.dayOfWeek() - 1;
    if (jourSemaine < 0) jourSemaine = 6;

    int ligne = 1;
    int colonne = jourSemaine;

    for (int jour = 1; jour <= m_dateCalendrier.daysInMonth(); ++jour) {
        QDate dateCourante(m_dateCalendrier.year(), m_dateCalendrier.month(), jour);

        QPushButton* btnJour = new QPushButton(QString::number(jour));
        btnJour->setMinimumSize(50, 50);
        btnJour->setProperty("date", dateCourante);

        QString style = "QPushButton { background-color: white; border: 2px solid #bdc3c7; border-radius: 8px; font-weight: bold; font-size: 14px; }"
                        "QPushButton:hover { background-color: #ecf0f1; border-color: #3498db; }";

        if (m_seancesParDate.contains(dateCourante) && m_seancesParDate[dateCourante] > 0) {
            style = "QPushButton { background-color: #e74c3c; color: white; border: 2px solid #c0392b; border-radius: 8px; font-weight: bold; font-size: 14px; }"
                    "QPushButton:hover { background-color: #c0392b; }";
            btnJour->setToolTip(QString("%1 séance(s) programmée(s)").arg(m_seancesParDate[dateCourante]));
        }

        if (dateCourante == QDate::currentDate()) {
            style = "QPushButton { background-color: #3498db; color: white; border: 2px solid #2980b9; border-radius: 8px; font-weight: bold; font-size: 14px; }"
                    "QPushButton:hover { background-color: #2980b9; }";
        }

        btnJour->setStyleSheet(style);

        connect(btnJour, &QPushButton::clicked, [this, dateCourante]() {
            onCalendrierDateClicked(dateCourante);
        });

        ui->gridLayout_calendrier->addWidget(btnJour, ligne, colonne);

        colonne++;
        if (colonne > 6) {
            colonne = 0;
            ligne++;
        }
    }
}

void MainWindow::marquerDatesAvecSeances()
{
    m_seancesParDate = Seance::getSeancesParMois(m_dateCalendrier.month(), m_dateCalendrier.year());
}

void MainWindow::onCalendrierDateClicked(const QDate &date)
{
    afficherDetailsDate(date);
}

void MainWindow::afficherDetailsDate(const QDate &date)
{
    QList<Seance> seances = Seance::getSeancesParDate(date);

    if (seances.isEmpty()) {
        QMessageBox::information(this, "Calendrier",
                                 QString("📅 %1\n\n❌ Aucune séance programmée pour cette date.")
                                     .arg(date.toString("dd/MM/yyyy")));
    } else {
        QString message = QString("📅 %1\n\n✅ Séances programmées:\n\n").arg(date.toString("dd/MM/yyyy"));

        for (const Seance& s : seances) {
            message += QString("🔹 **Séance ID: %1**\n"
                               "   ⏰ Heure: %2\n"
                               "   🕐 Durée: %3 min\n"
                               "   📋 Type: %4\n"
                               "   🚗 Appareil: %5\n"
                               "   👤 Client ID: %6\n"
                               "   👨‍🏫 Moniteur ID: %7\n\n")
                           .arg(s.getId())
                           .arg(s.getHeure().toString("HH:mm"))
                           .arg(s.getDuree())
                           .arg(s.getType())
                           .arg(s.getAppareil())
                           .arg(s.getIdClient())
                           .arg(s.getIdMoniteur());
        }

        QDialog dialog(this);
        dialog.setWindowTitle("🚗 RoadMaster - Détails des Séances");
        dialog.setFixedSize(500, 400);
        dialog.setStyleSheet("QDialog { background-color: #f8f9fa; }");

        QVBoxLayout *layout = new QVBoxLayout(&dialog);

        QLabel *titleLabel = new QLabel("Détails des Séances");
        titleLabel->setStyleSheet("QLabel { color: #2c3e50; font-size: 18px; font-weight: bold; padding: 10px; }");
        titleLabel->setAlignment(Qt::AlignCenter);
        layout->addWidget(titleLabel);

        QTextEdit *textEdit = new QTextEdit();
        textEdit->setPlainText(message);
        textEdit->setReadOnly(true);
        textEdit->setStyleSheet("QTextEdit { background-color: white; border: 2px solid #bdc3c7; border-radius: 8px; padding: 15px; font-size: 12px; }");

        QPushButton *btnFermer = new QPushButton("Fermer");
        btnFermer->setStyleSheet("QPushButton { background-color: #3498db; color: white; border: none; padding: 10px; border-radius: 5px; font-weight: bold; }"
                                 "QPushButton:hover { background-color: #2980b9; }");
        connect(btnFermer, &QPushButton::clicked, &dialog, &QDialog::accept);

        layout->addWidget(textEdit);
        layout->addWidget(btnFermer);

        dialog.exec();
    }
}

void MainWindow::onMoisPrecedent()
{
    m_dateCalendrier = m_dateCalendrier.addMonths(-1);
    updateCalendrier();
}

void MainWindow::onMoisSuivant()
{
    m_dateCalendrier = m_dateCalendrier.addMonths(1);
    updateCalendrier();
}

void MainWindow::onAfficherCalendrier()
{
    updateCalendrier();
}

MainWindow::~MainWindow()
{
    delete ui;
}
