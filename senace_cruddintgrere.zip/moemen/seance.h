#ifndef SEANCE_H
#define SEANCE_H

#include <QString>
#include <QDate>
#include <QTime>
#include <QSqlQuery>
#include <QSqlQueryModel>

class Seance
{
private:
    int id_seance;
    QDate date_seance;
    QTime heure_debut;
    int duree;
    QString type;
    QString appareil;

public:
    Seance();
    Seance(int id, QDate date, QTime heure, int duree, QString type, QString appareil);

    int getId() const { return id_seance; }
    QDate getDate() const { return date_seance; }
    QTime getHeureDebut() const { return heure_debut; }
    int getDuree() const { return duree; }
    QString getType() const { return type; }
    QString getAppareil() const { return appareil; }

    void setId(int id) { id_seance = id; }
    void setDate(QDate d) { date_seance = d; }
    void setHeureDebut(QTime h) { heure_debut = h; }
    void setDuree(int d) { duree = d; }
    void setType(QString t) { type = t; }
    void setAppareil(QString a) { appareil = a; }

    bool ajouter();
    bool modifier();
    bool supprimer(int id);
    static QSqlQueryModel* afficher();
    static QSqlQueryModel* rechercher(const QString& critere);
};

#endif // SEANCE_H
