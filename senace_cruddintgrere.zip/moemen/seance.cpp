#include "seance.h"
#include "connection.h"
#include <QDebug>

Seance::Seance() : id_seance(0), duree(0) {}

Seance::Seance(int id, QDate date, QTime heure, int duree, QString type, QString appareil)
    : id_seance(id), date_seance(date), heure_debut(heure), duree(duree), type(type), appareil(appareil)
{}

bool Seance::ajouter()
{
    QSqlQuery query;
    query.prepare("INSERT INTO seance (id_seance, date_seance, heure_debut, duree, type, appareil) "
                  "VALUES (:id, :date, :heure, :duree, :type, :appareil)");

    query.bindValue(":id", id_seance);
    query.bindValue(":date", date_seance);
    query.bindValue(":heure", heure_debut);
    query.bindValue(":duree", duree);
    query.bindValue(":type", type);
    query.bindValue(":appareil", appareil);

    return query.exec();
}

bool Seance::modifier()
{
    QSqlQuery query;
    query.prepare("UPDATE seance SET date_seance=:date, heure_debut=:heure, duree=:duree, "
                  "type=:type, appareil=:appareil WHERE id_seance=:id");

    query.bindValue(":id", id_seance);
    query.bindValue(":date", date_seance);
    query.bindValue(":heure", heure_debut);
    query.bindValue(":duree", duree);
    query.bindValue(":type", type);
    query.bindValue(":appareil", appareil);

    return query.exec();
}

bool Seance::supprimer(int id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM seance WHERE id_seance = :id");
    query.bindValue(":id", id);
    return query.exec();
}

QSqlQueryModel* Seance::afficher()
{
    QSqlQueryModel* model = new QSqlQueryModel();
    model->setQuery("SELECT * FROM seance");

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Date"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Heure Début"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Durée"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Type"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("Appareil"));

    return model;
}

QSqlQueryModel* Seance::rechercher(const QString& critere)
{
    QSqlQueryModel* model = new QSqlQueryModel();
    QString queryStr = "SELECT * FROM seance WHERE "
                       "CAST(id_seance AS TEXT) LIKE '%" + critere + "%' "
                                   "OR type LIKE '%" + critere + "%' "
                                   "OR appareil LIKE '%" + critere + "%'";
    model->setQuery(queryStr);

    model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Date"));
    model->setHeaderData(2, Qt::Horizontal, QObject::tr("Heure Début"));
    model->setHeaderData(3, Qt::Horizontal, QObject::tr("Durée"));
    model->setHeaderData(4, Qt::Horizontal, QObject::tr("Type"));
    model->setHeaderData(5, Qt::Horizontal, QObject::tr("Appareil"));

    return model;
}
