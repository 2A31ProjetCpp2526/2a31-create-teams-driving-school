#include "mainwindow.h"
#include "seance.h"
#include "ui_mainwindow.h"
#include "connection.h"
#include <QWidget>
#include <QLabel>
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Connexions boutons de navigation
    connect(ui->seance, &QPushButton::clicked, this, &MainWindow::seanceclick);
    connect(ui->employe, &QPushButton::clicked, this, &MainWindow::employeclick);
    connect(ui->client, &QPushButton::clicked, this, &MainWindow::clientclick);
    connect(ui->vehicule, &QPushButton::clicked, this, &MainWindow::vehiculeclick);
    connect(ui->contrat, &QPushButton::clicked, this, &MainWindow::contratclick);

    // Connexion à la base
    Connection c;
    if (c.createConnect()) {
        qDebug() << "✅ Base connectée via ODBC.";
        refreshTable();
    } else {
        QMessageBox::critical(this, "Erreur", "❌ Connexion à la base de données échouée !");
    }

    ui->stack->setCurrentIndex(0);
}

void MainWindow::seanceclick()
{
    ui->stack->setCurrentIndex(0);
    refreshTable();
}

void MainWindow::employeclick() { ui->stack->setCurrentIndex(1); }
void MainWindow::clientclick()   { ui->stack->setCurrentIndex(2); }
void MainWindow::vehiculeclick() { ui->stack->setCurrentIndex(3); }
void MainWindow::contratclick()  { ui->stack->setCurrentIndex(4); }

void MainWindow::refreshTable()
{
    QSqlQueryModel *model = Seance::afficher();
    ui->tableView_seances->setModel(model);
    ui->tableView_seances->resizeColumnsToContents();
}

void MainWindow::clearFields()
{
    ui->lineEdit_id->clear();
    ui->dateEdit_date->setDate(QDate::currentDate());
    ui->timeEdit_heure->setTime(QTime::currentTime());
    ui->lineEdit_duree->clear();
    ui->comboBox_type->setCurrentIndex(0);
    ui->lineEdit_appareil->clear();
    ui->lineEdit_id_client->clear();
    ui->lineEdit_immatricule->clear();
    ui->lineEdit_id_moniteur->clear();
    ui->lineEdit_recherche->clear();
}

void MainWindow::on_pushButton_valider_clicked()
{
    qDebug() << "=== BOUTON VALIDER CLIQUE ===";

    int id = ui->lineEdit_id->text().toInt();
    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();
    int id_client = ui->lineEdit_id_client->text().toInt();
    QString immatricule = ui->lineEdit_immatricule->text();
    int id_moniteur = ui->lineEdit_id_moniteur->text().toInt();

    qDebug() << "Valeurs saisies:";
    qDebug() << "ID:" << id;
    qDebug() << "Date:" << date;
    qDebug() << "Heure:" << heure;
    qDebug() << "Durée:" << duree;
    qDebug() << "Type:" << type;
    qDebug() << "Appareil:" << appareil;
    qDebug() << "ID Client:" << id_client;
    qDebug() << "Immatricule:" << immatricule;
    qDebug() << "ID Moniteur:" << id_moniteur;

    // Validation des champs
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ L'ID doit être supérieur à 0 !");
        qDebug() << "❌ Validation échouée: ID invalide";
        return;
    }
    if (duree <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ La durée doit être supérieure à 0 !");
        qDebug() << "❌ Validation échouée: Durée invalide";
        return;
    }
    if (appareil.isEmpty()) {
        QMessageBox::warning(this, "Attention", "⚠️ L'appareil ne peut pas être vide !");
        qDebug() << "❌ Validation échouée: Appareil vide";
        return;
    }
    if (id_client <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ L'ID client doit être supérieur à 0 !");
        qDebug() << "❌ Validation échouée: ID client invalide";
        return;
    }
    if (immatricule.isEmpty()) {
        QMessageBox::warning(this, "Attention", "⚠️ L'immatricule ne peut pas être vide !");
        qDebug() << "❌ Validation échouée: Immatricule vide";
        return;
    }
    if (id_moniteur <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ L'ID moniteur doit être supérieur à 0 !");
        qDebug() << "❌ Validation échouée: ID moniteur invalide";
        return;
    }

    // Vérification si l'ID existe déjà
    if (Seance::existeDeja(id)) {
        QMessageBox::warning(this, "Attention", "❌ Cet ID existe déjà ! Veuillez utiliser un ID différent.");
        qDebug() << "❌ ID existe déjà";
        return;
    }

    qDebug() << "✅ Toutes les validations passées, création de la séance...";

    Seance seance(id, date, heure, duree, type, appareil, id_client, immatricule, id_moniteur);

    if (seance.ajouter()) {
        QMessageBox::information(this, "Succès", "✅ Séance ajoutée avec succès !");
        refreshTable();
        clearFields();
        qDebug() << "✅ Séance ajoutée avec succès !";
    } else {
        QMessageBox::critical(this, "Erreur", "❌ Erreur lors de l'ajout !");
        qDebug() << "❌ Échec de l'ajout";
    }

    qDebug() << "=== FIN BOUTON VALIDER ===";
}

void MainWindow::on_pushButton_modifier_clicked()
{
    qDebug() << "=== BOUTON MODIFIER CLIQUE ===";

    int id = ui->lineEdit_id->text().toInt();
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez sélectionner une séance à modifier !");
        qDebug() << "❌ Aucune séance sélectionnée";
        return;
    }

    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();
    int id_client = ui->lineEdit_id_client->text().toInt();
    QString immatricule = ui->lineEdit_immatricule->text();
    int id_moniteur = ui->lineEdit_id_moniteur->text().toInt();

    qDebug() << "Modification séance ID:" << id;

    // Validation des champs
    if (duree <= 0 || appareil.isEmpty() || id_client <= 0 || immatricule.isEmpty() || id_moniteur <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez remplir tous les champs correctement !");
        qDebug() << "❌ Validation échouée";
        return;
    }

    Seance seance(id, date, heure, duree, type, appareil, id_client, immatricule, id_moniteur);

    if (seance.modifier()) {
        QMessageBox::information(this, "Succès", "✅ Séance modifiée avec succès !");
        refreshTable();
        clearFields();
        qDebug() << "✅ Séance modifiée avec succès !";
    } else {
        QMessageBox::critical(this, "Erreur", "❌ Erreur lors de la modification !");
        qDebug() << "❌ Échec de la modification";
    }

    qDebug() << "=== FIN BOUTON MODIFIER ===";
}

void MainWindow::on_pushButton_supprimer_clicked()
{
    qDebug() << "=== BOUTON SUPPRIMER CLIQUE ===";

    int id = ui->lineEdit_id->text().toInt();

    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "⚠️ Veuillez sélectionner une séance à supprimer !");
        qDebug() << "❌ Aucune séance sélectionnée";
        return;
    }

    if (QMessageBox::question(this, "Confirmation",
                              "Voulez-vous vraiment supprimer la séance ID " + QString::number(id) + " ?",
                              QMessageBox::Yes | QMessageBox::No)
        == QMessageBox::Yes)
    {
        Seance s;
        if (s.supprimer(id)) {
            QMessageBox::information(this, "Succès", "✅ Séance supprimée avec succès !");
            refreshTable();
            clearFields();
            qDebug() << "✅ Séance supprimée avec succès !";
        } else {
            QMessageBox::critical(this, "Erreur", "❌ Erreur lors de la suppression !");
            qDebug() << "❌ Échec de la suppression";
        }
    }

    qDebug() << "=== FIN BOUTON SUPPRIMER ===";
}

void MainWindow::on_pushButton_recherche_clicked()
{
    QString critere = ui->lineEdit_recherche->text().trimmed();

    if (critere.isEmpty()) {
        refreshTable();
        qDebug() << "🔍 Recherche: Affichage de tous les résultats";
    } else {
        QSqlQueryModel *model = Seance::rechercher(critere);
        ui->tableView_seances->setModel(model);

        int rowCount = model->rowCount();
        if (rowCount == 0) {
            QMessageBox::information(this, "Recherche", "🔍 Aucune séance trouvée pour : " + critere);
            qDebug() << "🔍 Recherche: Aucun résultat pour" << critere;
        } else {
            qDebug() << "🔍 Recherche:" << rowCount << "résultats trouvés pour" << critere;
        }
    }
}

void MainWindow::on_pushButton_trier_clicked()
{
    QString critere = ui->comboBox_trier->currentText();
    QString orderBy;

    if (critere == "Par ID") {
        orderBy = "ID_SEANCE";
    } else if (critere == "Par Date") {
        orderBy = "DATE_SEANCE";
    } else if (critere == "Par Heure") {
        orderBy = "HEURE_DEBUT";
    } else if (critere == "Par Durée") {
        orderBy = "DUREE";
    } else if (critere == "Par Type") {
        orderBy = "TYPE";
    } else {
        orderBy = "ID_SEANCE";
    }

    QSqlQueryModel *model = Seance::trier(orderBy);
    ui->tableView_seances->setModel(model);
    qDebug() << "📊 Tri par:" << orderBy;
}

void MainWindow::on_pushButton_effacer_clicked()
{
    clearFields();
    qDebug() << "🧹 Champs effacés";
}

void MainWindow::on_pushButton_rafraichir_clicked()
{
    refreshTable();
    qDebug() << "🔄 Table rafraîchie";
}

void MainWindow::on_tableView_seances_clicked(const QModelIndex &index)
{
    if (!index.isValid()) return;

    int id = index.sibling(index.row(), 0).data().toInt();
    QString immatricule = index.sibling(index.row(), 1).data().toString();
    int id_client = index.sibling(index.row(), 2).data().toInt();
    int id_moniteur = index.sibling(index.row(), 3).data().toInt();
    QDate date = index.sibling(index.row(), 4).data().toDate();
    QString heure_str = index.sibling(index.row(), 5).data().toString();
    QString type = index.sibling(index.row(), 6).data().toString();
    QString appareil = index.sibling(index.row(), 7).data().toString();
    int duree = index.sibling(index.row(), 8).data().toInt();

    // Convertir la chaîne heure en QTime
    QTime heure = QTime::fromString(heure_str, "HH:mm");

    ui->lineEdit_id->setText(QString::number(id));
    ui->dateEdit_date->setDate(date);
    ui->timeEdit_heure->setTime(heure);
    ui->lineEdit_duree->setText(QString::number(duree));

    int indexType = ui->comboBox_type->findText(type);
    if (indexType != -1)
        ui->comboBox_type->setCurrentIndex(indexType);

    ui->lineEdit_appareil->setText(appareil);
    ui->lineEdit_id_client->setText(QString::number(id_client));
    ui->lineEdit_immatricule->setText(immatricule);
    ui->lineEdit_id_moniteur->setText(QString::number(id_moniteur));

    qDebug() << "📋 Séance sélectionnée - ID:" << id;
}

MainWindow::~MainWindow()
{
    delete ui;
}
