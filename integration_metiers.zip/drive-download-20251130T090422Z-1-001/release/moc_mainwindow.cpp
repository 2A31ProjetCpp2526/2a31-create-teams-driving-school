/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.7.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtGui/qtextcursor.h>
#include <QtCore/qmetatype.h>

#include <QtCore/qtmochelpers.h>

#include <memory>


#include <QtCore/qxptype_traits.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.7.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSMainWindowENDCLASS_t {};
constexpr auto qt_meta_stringdata_CLASSMainWindowENDCLASS = QtMocHelpers::stringData(
    "MainWindow",
    "seanceclick",
    "",
    "employeclick",
    "clientclick",
    "vehiculeclick",
    "moniteurclick",
    "cercuitclick",
    "calendrierclick",
    "on_pushButton_valider_clicked",
    "on_pushButton_modifier_clicked",
    "on_pushButton_supprimer_clicked",
    "on_pushButton_recherche_clicked",
    "on_comboBox_trier_currentTextChanged",
    "text",
    "on_pushButton_effacer_clicked",
    "on_pushButton_rafraichir_clicked",
    "on_pushButton_export_clicked",
    "on_pushButton_statistiques_clicked",
    "on_tableView_seances_clicked",
    "QModelIndex",
    "index",
    "on_pushButton_envoyer_clicked",
    "on_lineEdit_recherche_textChanged",
    "onCalendrierDateClicked",
    "date",
    "onMoisPrecedent",
    "onMoisSuivant",
    "onAfficherCalendrier",
    "on_pushButton_validervehicule_clicked",
    "on_pushButton_supprimervehicule_clicked",
    "on_pushButton_modifiervehicule_clicked",
    "on_pushButton_rechercheVehicule_clicked",
    "on_lineEdit_rechercheVehicule_textChanged",
    "on_comboBox_trierVehicule_currentIndexChanged",
    "on_pushButton_exporter_clicked",
    "on_pushButton_statistiques_2_clicked",
    "on_tableView_vehicules_clicked",
    "on_pushButton_historique_clicked",
    "updateAssuranceTable",
    "updateAssuranceAlertPanel",
    "updateMetiersBadge",
    "showAssuranceNotifications",
    "showNotification",
    "title",
    "message",
    "on_tabWidget_4_currentChanged",
    "on_pushButton_validercircuit_clicked",
    "on_pushButton_modifiercircuit_clicked",
    "on_pushButton_supprimercircuit_clicked",
    "on_pushButton_recherchecircuit_clicked",
    "on_tableView_circuits_clicked",
    "on_tableView_circuits_recherche_clicked",
    "on_comboBox_trier_circuit_currentIndexChanged",
    "on_pushButton_supprimercircuit_bas_clicked",
    "on_pushButton_export_circuit_clicked",
    "on_btnAjouter_clicked",
    "on_btnModifier_clicked",
    "on_btnSupprimer_clicked",
    "on_btnChercher_clicked",
    "on_btnClear_clicked",
    "on_tableWidget_6_itemClicked",
    "QTableWidgetItem*",
    "item",
    "on_lineEditRecherche_textChanged",
    "arg1",
    "on_comboBoxTrier_currentIndexChanged",
    "on_btnExporterPDF_clicked",
    "on_btnGenererQRClient_clicked",
    "on_btnGenererQR_clicked",
    "on_pushButton_30_clicked",
    "on_btnShowClientOnMap_clicked",
    "on_pushButton_26_clicked",
    "on_pushButton_27_clicked",
    "on_pushButton_28_clicked",
    "on_tableWidget_5_itemSelectionChanged",
    "on_comboBox_8_currentIndexChanged",
    "on_exportPdfBtn_clicked",
    "on_addContratBtn_clicked",
    "on_updateContratBtn_clicked",
    "on_deleteContratBtn_clicked",
    "on_Modifiermoniteur_clicked",
    "on_supprimermoniteur_clicked",
    "on_moniteurTable_cellClicked",
    "row",
    "column",
    "on_searchBtn_clicked",
    "afficherStatistiqueClient",
    "selectClientByQRCode",
    "clientId",
    "on_notification_clicked",
    "on_voicechat_clicked",
    "on_stat_clicked",
    "on_exportPdfBtnMoniteur_clicked",
    "on_sortBtn_clicked"
);
#else  // !QT_MOC_HAS_STRINGDATA
#error "qtmochelpers.h not found or too old."
#endif // !QT_MOC_HAS_STRINGDATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSMainWindowENDCLASS[] = {

 // content:
      12,       // revision
       0,       // classname
       0,    0, // classinfo
      81,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  500,    2, 0x08,    1 /* Private */,
       3,    0,  501,    2, 0x08,    2 /* Private */,
       4,    0,  502,    2, 0x08,    3 /* Private */,
       5,    0,  503,    2, 0x08,    4 /* Private */,
       6,    0,  504,    2, 0x08,    5 /* Private */,
       7,    0,  505,    2, 0x08,    6 /* Private */,
       8,    0,  506,    2, 0x08,    7 /* Private */,
       9,    0,  507,    2, 0x08,    8 /* Private */,
      10,    0,  508,    2, 0x08,    9 /* Private */,
      11,    0,  509,    2, 0x08,   10 /* Private */,
      12,    0,  510,    2, 0x08,   11 /* Private */,
      13,    1,  511,    2, 0x08,   12 /* Private */,
      15,    0,  514,    2, 0x08,   14 /* Private */,
      16,    0,  515,    2, 0x08,   15 /* Private */,
      17,    0,  516,    2, 0x08,   16 /* Private */,
      18,    0,  517,    2, 0x08,   17 /* Private */,
      19,    1,  518,    2, 0x08,   18 /* Private */,
      22,    0,  521,    2, 0x08,   20 /* Private */,
      23,    1,  522,    2, 0x08,   21 /* Private */,
      24,    1,  525,    2, 0x08,   23 /* Private */,
      26,    0,  528,    2, 0x08,   25 /* Private */,
      27,    0,  529,    2, 0x08,   26 /* Private */,
      28,    0,  530,    2, 0x08,   27 /* Private */,
      29,    0,  531,    2, 0x08,   28 /* Private */,
      30,    0,  532,    2, 0x08,   29 /* Private */,
      31,    0,  533,    2, 0x08,   30 /* Private */,
      32,    0,  534,    2, 0x08,   31 /* Private */,
      33,    1,  535,    2, 0x08,   32 /* Private */,
      34,    1,  538,    2, 0x08,   34 /* Private */,
      35,    0,  541,    2, 0x08,   36 /* Private */,
      36,    0,  542,    2, 0x08,   37 /* Private */,
      37,    1,  543,    2, 0x08,   38 /* Private */,
      38,    0,  546,    2, 0x08,   40 /* Private */,
      39,    0,  547,    2, 0x08,   41 /* Private */,
      40,    0,  548,    2, 0x08,   42 /* Private */,
      41,    0,  549,    2, 0x08,   43 /* Private */,
      42,    0,  550,    2, 0x08,   44 /* Private */,
      43,    2,  551,    2, 0x08,   45 /* Private */,
      46,    1,  556,    2, 0x08,   48 /* Private */,
      47,    0,  559,    2, 0x08,   50 /* Private */,
      48,    0,  560,    2, 0x08,   51 /* Private */,
      49,    0,  561,    2, 0x08,   52 /* Private */,
      50,    0,  562,    2, 0x08,   53 /* Private */,
      51,    1,  563,    2, 0x08,   54 /* Private */,
      52,    1,  566,    2, 0x08,   56 /* Private */,
      53,    1,  569,    2, 0x08,   58 /* Private */,
      54,    0,  572,    2, 0x08,   60 /* Private */,
      55,    0,  573,    2, 0x08,   61 /* Private */,
      56,    0,  574,    2, 0x08,   62 /* Private */,
      57,    0,  575,    2, 0x08,   63 /* Private */,
      58,    0,  576,    2, 0x08,   64 /* Private */,
      59,    0,  577,    2, 0x08,   65 /* Private */,
      60,    0,  578,    2, 0x08,   66 /* Private */,
      61,    1,  579,    2, 0x08,   67 /* Private */,
      64,    1,  582,    2, 0x08,   69 /* Private */,
      66,    1,  585,    2, 0x08,   71 /* Private */,
      67,    0,  588,    2, 0x08,   73 /* Private */,
      68,    0,  589,    2, 0x08,   74 /* Private */,
      69,    0,  590,    2, 0x08,   75 /* Private */,
      70,    0,  591,    2, 0x08,   76 /* Private */,
      71,    0,  592,    2, 0x08,   77 /* Private */,
      72,    0,  593,    2, 0x08,   78 /* Private */,
      73,    0,  594,    2, 0x08,   79 /* Private */,
      74,    0,  595,    2, 0x08,   80 /* Private */,
      75,    0,  596,    2, 0x08,   81 /* Private */,
      76,    1,  597,    2, 0x08,   82 /* Private */,
      77,    0,  600,    2, 0x08,   84 /* Private */,
      78,    0,  601,    2, 0x08,   85 /* Private */,
      79,    0,  602,    2, 0x08,   86 /* Private */,
      80,    0,  603,    2, 0x08,   87 /* Private */,
      81,    0,  604,    2, 0x08,   88 /* Private */,
      82,    0,  605,    2, 0x08,   89 /* Private */,
      83,    2,  606,    2, 0x08,   90 /* Private */,
      86,    0,  611,    2, 0x08,   93 /* Private */,
      87,    0,  612,    2, 0x08,   94 /* Private */,
      88,    1,  613,    2, 0x08,   95 /* Private */,
      90,    0,  616,    2, 0x08,   97 /* Private */,
      91,    0,  617,    2, 0x08,   98 /* Private */,
      92,    0,  618,    2, 0x08,   99 /* Private */,
      93,    0,  619,    2, 0x08,  100 /* Private */,
      94,    0,  620,    2, 0x08,  101 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::QDate,   25,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   14,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   44,   45,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 62,   63,
    QMetaType::Void, QMetaType::QString,   65,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int,   84,   85,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   89,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSMainWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSMainWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSMainWindowENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>,
        // method 'seanceclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'employeclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'clientclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'vehiculeclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'moniteurclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cercuitclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'calendrierclick'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_valider_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_modifier_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_supprimer_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_recherche_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comboBox_trier_currentTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_pushButton_effacer_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_rafraichir_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_export_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_statistiques_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableView_seances_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_pushButton_envoyer_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lineEdit_recherche_textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'onCalendrierDateClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QDate &, std::false_type>,
        // method 'onMoisPrecedent'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onMoisSuivant'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'onAfficherCalendrier'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_validervehicule_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_supprimervehicule_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_modifiervehicule_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_rechercheVehicule_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_lineEdit_rechercheVehicule_textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_comboBox_trierVehicule_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_exporter_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_statistiques_2_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableView_vehicules_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_pushButton_historique_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateAssuranceTable'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateAssuranceAlertPanel'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateMetiersBadge'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showAssuranceNotifications'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'showNotification'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_tabWidget_4_currentChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_validercircuit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_modifiercircuit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_supprimercircuit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_recherchecircuit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableView_circuits_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_tableView_circuits_recherche_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>,
        // method 'on_comboBox_trier_circuit_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_pushButton_supprimercircuit_bas_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_export_circuit_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnAjouter_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnModifier_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnSupprimer_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnChercher_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnClear_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableWidget_6_itemClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QTableWidgetItem *, std::false_type>,
        // method 'on_lineEditRecherche_textChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_comboBoxTrier_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_btnExporterPDF_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnGenererQRClient_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnGenererQR_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_30_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_btnShowClientOnMap_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_26_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_27_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_pushButton_28_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_tableWidget_5_itemSelectionChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_comboBox_8_currentIndexChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_exportPdfBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_addContratBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_updateContratBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_deleteContratBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_Modifiermoniteur_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_supprimermoniteur_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_moniteurTable_cellClicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        QtPrivate::TypeAndForceComplete<int, std::false_type>,
        // method 'on_searchBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'afficherStatistiqueClient'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'selectClientByQRCode'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'on_notification_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_voicechat_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_stat_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_exportPdfBtnMoniteur_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'on_sortBtn_clicked'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->seanceclick(); break;
        case 1: _t->employeclick(); break;
        case 2: _t->clientclick(); break;
        case 3: _t->vehiculeclick(); break;
        case 4: _t->moniteurclick(); break;
        case 5: _t->cercuitclick(); break;
        case 6: _t->calendrierclick(); break;
        case 7: _t->on_pushButton_valider_clicked(); break;
        case 8: _t->on_pushButton_modifier_clicked(); break;
        case 9: _t->on_pushButton_supprimer_clicked(); break;
        case 10: _t->on_pushButton_recherche_clicked(); break;
        case 11: _t->on_comboBox_trier_currentTextChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 12: _t->on_pushButton_effacer_clicked(); break;
        case 13: _t->on_pushButton_rafraichir_clicked(); break;
        case 14: _t->on_pushButton_export_clicked(); break;
        case 15: _t->on_pushButton_statistiques_clicked(); break;
        case 16: _t->on_tableView_seances_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 17: _t->on_pushButton_envoyer_clicked(); break;
        case 18: _t->on_lineEdit_recherche_textChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 19: _t->onCalendrierDateClicked((*reinterpret_cast< std::add_pointer_t<QDate>>(_a[1]))); break;
        case 20: _t->onMoisPrecedent(); break;
        case 21: _t->onMoisSuivant(); break;
        case 22: _t->onAfficherCalendrier(); break;
        case 23: _t->on_pushButton_validervehicule_clicked(); break;
        case 24: _t->on_pushButton_supprimervehicule_clicked(); break;
        case 25: _t->on_pushButton_modifiervehicule_clicked(); break;
        case 26: _t->on_pushButton_rechercheVehicule_clicked(); break;
        case 27: _t->on_lineEdit_rechercheVehicule_textChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 28: _t->on_comboBox_trierVehicule_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 29: _t->on_pushButton_exporter_clicked(); break;
        case 30: _t->on_pushButton_statistiques_2_clicked(); break;
        case 31: _t->on_tableView_vehicules_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 32: _t->on_pushButton_historique_clicked(); break;
        case 33: _t->updateAssuranceTable(); break;
        case 34: _t->updateAssuranceAlertPanel(); break;
        case 35: _t->updateMetiersBadge(); break;
        case 36: _t->showAssuranceNotifications(); break;
        case 37: _t->showNotification((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 38: _t->on_tabWidget_4_currentChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 39: _t->on_pushButton_validercircuit_clicked(); break;
        case 40: _t->on_pushButton_modifiercircuit_clicked(); break;
        case 41: _t->on_pushButton_supprimercircuit_clicked(); break;
        case 42: _t->on_pushButton_recherchecircuit_clicked(); break;
        case 43: _t->on_tableView_circuits_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 44: _t->on_tableView_circuits_recherche_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 45: _t->on_comboBox_trier_circuit_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 46: _t->on_pushButton_supprimercircuit_bas_clicked(); break;
        case 47: _t->on_pushButton_export_circuit_clicked(); break;
        case 48: _t->on_btnAjouter_clicked(); break;
        case 49: _t->on_btnModifier_clicked(); break;
        case 50: _t->on_btnSupprimer_clicked(); break;
        case 51: _t->on_btnChercher_clicked(); break;
        case 52: _t->on_btnClear_clicked(); break;
        case 53: _t->on_tableWidget_6_itemClicked((*reinterpret_cast< std::add_pointer_t<QTableWidgetItem*>>(_a[1]))); break;
        case 54: _t->on_lineEditRecherche_textChanged((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 55: _t->on_comboBoxTrier_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 56: _t->on_btnExporterPDF_clicked(); break;
        case 57: _t->on_btnGenererQRClient_clicked(); break;
        case 58: _t->on_btnGenererQR_clicked(); break;
        case 59: _t->on_pushButton_30_clicked(); break;
        case 60: _t->on_btnShowClientOnMap_clicked(); break;
        case 61: _t->on_pushButton_26_clicked(); break;
        case 62: _t->on_pushButton_27_clicked(); break;
        case 63: _t->on_pushButton_28_clicked(); break;
        case 64: _t->on_tableWidget_5_itemSelectionChanged(); break;
        case 65: _t->on_comboBox_8_currentIndexChanged((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 66: _t->on_exportPdfBtn_clicked(); break;
        case 67: _t->on_addContratBtn_clicked(); break;
        case 68: _t->on_updateContratBtn_clicked(); break;
        case 69: _t->on_deleteContratBtn_clicked(); break;
        case 70: _t->on_Modifiermoniteur_clicked(); break;
        case 71: _t->on_supprimermoniteur_clicked(); break;
        case 72: _t->on_moniteurTable_cellClicked((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 73: _t->on_searchBtn_clicked(); break;
        case 74: _t->afficherStatistiqueClient(); break;
        case 75: _t->selectClientByQRCode((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 76: _t->on_notification_clicked(); break;
        case 77: _t->on_voicechat_clicked(); break;
        case 78: _t->on_stat_clicked(); break;
        case 79: _t->on_exportPdfBtnMoniteur_clicked(); break;
        case 80: _t->on_sortBtn_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSMainWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 81)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 81;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 81)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 81;
    }
    return _id;
}
QT_WARNING_POP
