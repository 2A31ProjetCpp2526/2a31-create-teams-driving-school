/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QTimeEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QFrame *frame;
    QPushButton *seance;
    QPushButton *employe;
    QPushButton *client;
    QPushButton *vehicule;
    QPushButton *moniteur;
    QPushButton *cercuit;
    QPushButton *employe_2;
    QStackedWidget *stack;
    QWidget *page;
    QTabWidget *tabWidget;
    QWidget *tab_2;
    QLabel *label_2;
    QComboBox *comboBox_trier;
    QLineEdit *lineEdit_recherche;
    QLabel *label_3;
    QPushButton *pushButton_supprimer;
    QGroupBox *groupBox;
    QLabel *label_4;
    QLineEdit *lineEdit_id;
    QLabel *label_5;
    QDateEdit *dateEdit_date;
    QLabel *label_8;
    QTimeEdit *timeEdit_heure;
    QLabel *label_9;
    QLineEdit *lineEdit_duree;
    QLabel *label_10;
    QComboBox *comboBox_type;
    QPushButton *pushButton_valider;
    QPushButton *pushButton_modifier;
    QLabel *label_14;
    QLineEdit *lineEdit_appareil;
    QLabel *label_15;
    QLineEdit *lineEdit_id_client;
    QLineEdit *lineEdit_id_moniteur;
    QLineEdit *lineEdit_immatricule;
    QLabel *label_16;
    QLabel *label_17;
    QPushButton *pushButton_recherche;
    QLabel *label_12;
    QPushButton *pushButton_export;
    QLabel *label_13;
    QLabel *label_19;
    QLabel *label;
    QTableView *tableView_seances;
    QWidget *tab;
    QLabel *label_18;
    QLabel *label_21;
    QFrame *frame_2;
    QLabel *label_11;
    QPushButton *pushButton_statistiques;
    QWidget *tab_3;
    QLabel *label_25;
    QLabel *label_6;
    QWidget *widget;
    QLabel *label_23;
    QPushButton *pushButton_envoyer;
    QLabel *label_24;
    QLineEdit *lineEdit_id_2;
    QPushButton *calendrier;
    QPushButton *pushButton_mois_precedent;
    QPushButton *pushButton_mois_suivant;
    QPushButton *pushButton_rafraichir_calendrier;
    QTextEdit *label_mois_annee;
    QWidget *addWidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout_calendrier;
    QWidget *page_2;
    QTabWidget *tabWidget_2;
    QWidget *tab_12;
    QGroupBox *groupBox_5;
    QLabel *label_87;
    QLineEdit *lineEdit_24;
    QLabel *label_88;
    QLineEdit *lineEdit_25;
    QLabel *label_89;
    QLineEdit *lineEdit_26;
    QLabel *label_90;
    QLineEdit *lineEdit_27;
    QLabel *label_91;
    QLineEdit *lineEdit_28;
    QLabel *label_92;
    QLineEdit *lineEdit_29;
    QLabel *label_93;
    QDateEdit *dateEdit_5;
    QPushButton *pushButton_26;
    QLabel *label_94;
    QTableWidget *tableWidget_5;
    QLabel *label_95;
    QPushButton *pushButton_27;
    QLineEdit *lineEdit_30;
    QLabel *label_96;
    QPushButton *pushButton_28;
    QLineEdit *lineEdit_31;
    QLabel *label_97;
    QLabel *label_98;
    QComboBox *comboBox_8;
    QPushButton *pushButton_29;
    QCheckBox *checkBox_27;
    QWidget *tab_13;
    QVBoxLayout *verticalLayout_stat;
    QWidget *page_3;
    QTabWidget *tabWidget_3;
    QWidget *tab_crud;
    QHBoxLayout *horizontalLayout;
    QFrame *frameAjout;
    QVBoxLayout *verticalLayout;
    QLabel *labelTitre;
    QLabel *labelNom;
    QLineEdit *lineEditNom;
    QLabel *labelPrenom;
    QLineEdit *lineEditPrenom;
    QLabel *labelCIN;
    QLineEdit *lineEditCIN;
    QLabel *labelPoste;
    QDateEdit *jjj;
    QLabel *labelMotDePasse;
    QLineEdit *lineEditMotDePasse;
    QLabel *labelTelephone;
    QHBoxLayout *horizontalLayout_2;
    QLabel *labelIndicatif;
    QLineEdit *lineEditTelephone;
    QLabel *labelDateEmbauche;
    QLineEdit *lineEditPoste;
    QLabel *labelLatitude;
    QLineEdit *lineEditLatitude;
    QLabel *labelLongitude;
    QLineEdit *lineEditLongitude;
    QSpacerItem *verticalSpacer_8;
    QPushButton *btnAjouter;
    QPushButton *btnModifier;
    QSpacerItem *verticalSpacer_9;
    QWidget *widgetGestion;
    QVBoxLayout *verticalLayout_2;
    QLabel *labelGestion;
    QHBoxLayout *horizontalLayout_3;
    QLabel *labelAfficher;
    QLineEdit *lineEditRecherche;
    QPushButton *btnChercher;
    QPushButton *btnClear;
    QSpacerItem *horizontalSpacer;
    QLabel *labelTrier;
    QComboBox *comboBoxTrier;
    QTableWidget *tableWidget_6;
    QHBoxLayout *horizontalLayout_4;
    QLabel *labelSupprimer;
    QLineEdit *lineEditSupprimer;
    QPushButton *btnGenererQRClient;
    QPushButton *btnExporterPDF;
    QPushButton *btnSupprimer;
    QWidget *tab_ajouter;
    QVBoxLayout *verticalLayout_3;
    QWidget *tab_14;
    QLabel *label_102;
    QLabel *label_103;
    QLabel *labelClientMapSearch;
    QLineEdit *lineEditClientMapSearch;
    QPushButton *btnShowClientOnMap;
    QWidget *clientMapContainer;
    QWidget *page_4;
    QTabWidget *tabWidget_4;
    QWidget *tabAcceuil;
    QLabel *labelTitre_2;
    QGroupBox *groupBoxAjout;
    QLabel *labelImmatricule;
    QLineEdit *lineEdit_immatricule_2;
    QLabel *labelModele;
    QLineEdit *lineEdit_modele;
    QLabel *labelType;
    QComboBox *comboBox_type_2;
    QPushButton *pushButton_validervehicule;
    QPushButton *pushButton_modifiervehicule;
    QDateEdit *dateEdit_assurance;
    QLabel *label_104;
    QComboBox *comboBox_etat;
    QLabel *label_105;
    QComboBox *comboBox_transmission;
    QLabel *label_106;
    QLineEdit *lineEdit_rechercheVehicule;
    QPushButton *pushButton_exporterVehicule;
    QPushButton *pushButton_rechercheVehicule;
    QLabel *label_107;
    QComboBox *comboBox_trierVehicule;
    QPushButton *pushButton_supprimervehicule;
    QLineEdit *lineEdit_32;
    QTableView *tableView_vehicules;
    QWidget *tabStats;
    QLabel *label_109;
    QLabel *label_110;
    QPushButton *pushButton_statistiques_2;
    QLabel *label_27;
    QWidget *tab_15;
    QGroupBox *groupBox_6;
    QTableWidget *tableWidget_assurance;
    QLabel *label_expired;
    QLabel *label_soon;
    QGroupBox *groupBox_7;
    QPushButton *pushButton_historique;
    QWidget *page_5;
    QTabWidget *contratsTabWidget;
    QWidget *displayTab;
    QVBoxLayout *displayLayout;
    QHBoxLayout *toolbarLayout;
    QLineEdit *searchEdit;
    QPushButton *stat;
    QPushButton *searchBtn;
    QPushButton *sortBtn;
    QSpacerItem *toolbarSpacer;
    QPushButton *exportPdfBtnMoniteur;
    QTableWidget *moniteurTable;
    QPushButton *Modifiermoniteur;
    QPushButton *supprimermoniteur;
    QWidget *modifyTab;
    QVBoxLayout *modifyLayout;
    QFormLayout *modifyFormLayout;
    QLabel *modifyIdLabel;
    QLineEdit *idmod;
    QLabel *modifyNameLabel;
    QLineEdit *cinmod;
    QLabel *modifyEmailLabel;
    QLineEdit *nommod;
    QLabel *modifyPhoneLabel;
    QLineEdit *prenommod;
    QLabel *modifyCompanyLabel;
    QLineEdit *telmod;
    QLineEdit *permismod;
    QLineEdit *emailmod;
    QLabel *label_20;
    QLabel *label_22;
    QHBoxLayout *modifyButtonLayout;
    QSpacerItem *modifyButtonSpacer;
    QPushButton *addContratBtn;
    QPushButton *updateContratBtn;
    QPushButton *deleteContratBtn;
    QSpacerItem *modifyVerticalSpacer;
    QWidget *notificationTab;
    QVBoxLayout *notificationLayout;
    QHBoxLayout *notificationControlLayout;
    QPushButton *notification;
    QWidget *chatbotTab;
    QVBoxLayout *chatbotLayout;
    QPushButton *voicechat;
    QWidget *page_circuit;
    QTabWidget *tabWidget_circuit;
    QWidget *tabCircuitAccueil;
    QLabel *labelTitreCircuit;
    QPushButton *pushButton_export_circuit;
    QLabel *label_export_circuit;
    QGroupBox *groupBoxCircuit;
    QLabel *labelIdCircuit;
    QLineEdit *lineEdit_id_circuit;
    QLabel *labelNomCircuit;
    QLineEdit *lineEdit_nom_circuit;
    QLabel *labelDescCircuit;
    QTextEdit *textEdit_desc_circuit;
    QLabel *labelDistance;
    QLineEdit *lineEdit_distance;
    QLabel *labelDuree;
    QLineEdit *lineEdit_duree_circuit;
    QLabel *labelDifficulte;
    QComboBox *comboBox_difficulte;
    QLabel *labelImmatCircuit;
    QLineEdit *lineEdit_immat_circuit;
    QPushButton *pushButton_validercircuit;
    QPushButton *pushButton_modifiercircuit;
    QPushButton *pushButton_supprimercircuit;
    QTableView *tableView_circuits;
    QPushButton *pushButton_supprimercircuit_bas;
    QWidget *tabCircuitRecherche;
    QLabel *label_recherche_circuit;
    QLineEdit *lineEdit_recherche_circuit;
    QPushButton *pushButton_recherchecircuit;
    QLabel *label_trier_circuit;
    QComboBox *comboBox_trier_circuit;
    QTableView *tableView_circuits_recherche;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(1564, 948);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName("centralwidget");
        frame = new QFrame(centralwidget);
        frame->setObjectName("frame");
        frame->setGeometry(QRect(0, 9, 201, 851));
        frame->setStyleSheet(QString::fromUtf8("background-color: #00008B; color: white;\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;"));
        frame->setFrameShape(QFrame::Shape::StyledPanel);
        frame->setFrameShadow(QFrame::Shadow::Raised);
        seance = new QPushButton(frame);
        seance->setObjectName("seance");
        seance->setGeometry(QRect(10, 520, 181, 71));
        seance->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        employe = new QPushButton(frame);
        employe->setObjectName("employe");
        employe->setGeometry(QRect(10, 170, 181, 71));
        employe->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        client = new QPushButton(frame);
        client->setObjectName("client");
        client->setGeometry(QRect(10, 290, 181, 71));
        client->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        vehicule = new QPushButton(frame);
        vehicule->setObjectName("vehicule");
        vehicule->setGeometry(QRect(10, 400, 181, 71));
        vehicule->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        moniteur = new QPushButton(frame);
        moniteur->setObjectName("moniteur");
        moniteur->setGeometry(QRect(10, 630, 181, 71));
        moniteur->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        cercuit = new QPushButton(frame);
        cercuit->setObjectName("cercuit");
        cercuit->setGeometry(QRect(10, 730, 181, 71));
        cercuit->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        employe_2 = new QPushButton(frame);
        employe_2->setObjectName("employe_2");
        employe_2->setGeometry(QRect(10, 60, 181, 71));
        employe_2->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";"));
        stack = new QStackedWidget(centralwidget);
        stack->setObjectName("stack");
        stack->setGeometry(QRect(200, 10, 1321, 861));
        page = new QWidget();
        page->setObjectName("page");
        tabWidget = new QTabWidget(page);
        tabWidget->setObjectName("tabWidget");
        tabWidget->setGeometry(QRect(0, 0, 1301, 851));
        tabWidget->setStyleSheet(QString::fromUtf8("\n"
"font: 14pt \"Segoe UI\";\n"
"color: rgb(0, 0, 0);\n"
"\n"
""));
        tabWidget->setMovable(false);
        tab_2 = new QWidget();
        tab_2->setObjectName("tab_2");
        label_2 = new QLabel(tab_2);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(380, 260, 251, 31));
        label_2->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        comboBox_trier = new QComboBox(tab_2);
        comboBox_trier->addItem(QString());
        comboBox_trier->addItem(QString());
        comboBox_trier->setObjectName("comboBox_trier");
        comboBox_trier->setGeometry(QRect(1080, 260, 101, 41));
        comboBox_trier->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  "));
        lineEdit_recherche = new QLineEdit(tab_2);
        lineEdit_recherche->setObjectName("lineEdit_recherche");
        lineEdit_recherche->setGeometry(QRect(620, 260, 141, 41));
        label_3 = new QLabel(tab_2);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(770, 260, 81, 41));
        label_3->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        pushButton_supprimer = new QPushButton(tab_2);
        pushButton_supprimer->setObjectName("pushButton_supprimer");
        pushButton_supprimer->setGeometry(QRect(860, 660, 171, 41));
        pushButton_supprimer->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(10, 0, 321, 791));
        groupBox->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"	font: 900 9pt \"Segoe UI\";\n"
"	font: 900 9pt \"Segoe UI\";\n"
"	font: 16pt \"Segoe UI\";\n"
"  \n"
"	background-color: rgb(135, 206, 235);\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;\n"
"}\n"
"QPushButton {\n"
"    background-color: #4682B4;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5A9BD5;\n"
"}"));
        label_4 = new QLabel(groupBox);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(30, 80, 131, 31));
        label_4->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_id = new QLineEdit(groupBox);
        lineEdit_id->setObjectName("lineEdit_id");
        lineEdit_id->setGeometry(QRect(30, 130, 161, 26));
        label_5 = new QLabel(groupBox);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(30, 170, 91, 20));
        label_5->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        dateEdit_date = new QDateEdit(groupBox);
        dateEdit_date->setObjectName("dateEdit_date");
        dateEdit_date->setGeometry(QRect(29, 210, 161, 26));
        dateEdit_date->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        label_8 = new QLabel(groupBox);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(30, 270, 191, 31));
        label_8->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        timeEdit_heure = new QTimeEdit(groupBox);
        timeEdit_heure->setObjectName("timeEdit_heure");
        timeEdit_heure->setGeometry(QRect(30, 320, 161, 26));
        timeEdit_heure->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        label_9 = new QLabel(groupBox);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(30, 370, 111, 20));
        label_9->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_duree = new QLineEdit(groupBox);
        lineEdit_duree->setObjectName("lineEdit_duree");
        lineEdit_duree->setGeometry(QRect(30, 410, 161, 26));
        label_10 = new QLabel(groupBox);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(30, 460, 81, 31));
        label_10->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        comboBox_type = new QComboBox(groupBox);
        comboBox_type->addItem(QString());
        comboBox_type->addItem(QString());
        comboBox_type->addItem(QString());
        comboBox_type->addItem(QString());
        comboBox_type->setObjectName("comboBox_type");
        comboBox_type->setGeometry(QRect(120, 465, 91, 31));
        comboBox_type->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        pushButton_valider = new QPushButton(groupBox);
        pushButton_valider->setObjectName("pushButton_valider");
        pushButton_valider->setGeometry(QRect(30, 730, 111, 41));
        pushButton_valider->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        pushButton_modifier = new QPushButton(groupBox);
        pushButton_modifier->setObjectName("pushButton_modifier");
        pushButton_modifier->setGeometry(QRect(190, 730, 121, 41));
        pushButton_modifier->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        label_14 = new QLabel(groupBox);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(10, 510, 141, 41));
        label_14->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_appareil = new QLineEdit(groupBox);
        lineEdit_appareil->setObjectName("lineEdit_appareil");
        lineEdit_appareil->setGeometry(QRect(160, 520, 151, 31));
        label_15 = new QLabel(groupBox);
        label_15->setObjectName("label_15");
        label_15->setGeometry(QRect(20, 560, 91, 31));
        label_15->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_id_client = new QLineEdit(groupBox);
        lineEdit_id_client->setObjectName("lineEdit_id_client");
        lineEdit_id_client->setGeometry(QRect(150, 570, 151, 31));
        lineEdit_id_moniteur = new QLineEdit(groupBox);
        lineEdit_id_moniteur->setObjectName("lineEdit_id_moniteur");
        lineEdit_id_moniteur->setGeometry(QRect(150, 670, 151, 31));
        lineEdit_immatricule = new QLineEdit(groupBox);
        lineEdit_immatricule->setObjectName("lineEdit_immatricule");
        lineEdit_immatricule->setGeometry(QRect(150, 620, 151, 31));
        label_16 = new QLabel(groupBox);
        label_16->setObjectName("label_16");
        label_16->setGeometry(QRect(20, 620, 121, 31));
        label_16->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        label_17 = new QLabel(groupBox);
        label_17->setObjectName("label_17");
        label_17->setGeometry(QRect(20, 670, 101, 31));
        label_17->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        pushButton_recherche = new QPushButton(tab_2);
        pushButton_recherche->setObjectName("pushButton_recherche");
        pushButton_recherche->setGeometry(QRect(810, 260, 141, 41));
        pushButton_recherche->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  "));
        label_12 = new QLabel(tab_2);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(970, 260, 101, 31));
        label_12->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        pushButton_export = new QPushButton(tab_2);
        pushButton_export->setObjectName("pushButton_export");
        pushButton_export->setGeometry(QRect(430, 660, 151, 41));
        pushButton_export->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        label_13 = new QLabel(tab_2);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(590, 670, 63, 31));
        label_13->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        label_19 = new QLabel(tab_2);
        label_19->setObjectName("label_19");
        label_19->setGeometry(QRect(360, 60, 901, 181));
        label_19->setPixmap(QPixmap(QString::fromUtf8("../../WhatsApp Image 2025-09-24 at 15.27.43.jpeg")));
        label = new QLabel(tab_2);
        label->setObjectName("label");
        label->setGeometry(QRect(500, 10, 481, 51));
        tableView_seances = new QTableView(tab_2);
        tableView_seances->setObjectName("tableView_seances");
        tableView_seances->setGeometry(QRect(360, 360, 841, 251));
        tableView_seances->setStyleSheet(QString::fromUtf8("background-color: #00008B;   /* \330\243\330\262\330\261\331\202 \330\272\330\247\331\205\331\202 */\n"
"    color: white;                /* \330\247\331\204\331\206\330\265 \330\243\330\250\331\212\330\266 */\n"
"    gridline-color: white;       /* \331\204\331\210\331\206 \330\247\331\204\330\256\330\267\331\210\330\267 */\n"
"    border-radius: 8px;          /* \330\255\331\210\330\247\331\201 \331\205\330\263\330\252\330\257\331\212\330\261\330\251 */\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: #34495e;   /* \330\261\331\205\330\247\330\257\331\212 \330\272\330\247\331\205\331\202 \331\204\331\204\331\200 header */\n"
"    color: white;\n"
"    padding: 4px;\n"
"    border: 1px solid #2c3e50;"));
        tabWidget->addTab(tab_2, QString());
        tab = new QWidget();
        tab->setObjectName("tab");
        label_18 = new QLabel(tab);
        label_18->setObjectName("label_18");
        label_18->setGeometry(QRect(920, 70, 63, 20));
        label_21 = new QLabel(tab);
        label_21->setObjectName("label_21");
        label_21->setGeometry(QRect(110, 20, 1121, 181));
        label_21->setPixmap(QPixmap(QString::fromUtf8("../../WhatsApp Image 2025-09-24 at 15.27.43.jpeg")));
        frame_2 = new QFrame(tab);
        frame_2->setObjectName("frame_2");
        frame_2->setGeometry(QRect(220, 220, 621, 411));
        frame_2->setStyleSheet(QString::fromUtf8("background-color: rgb(135, 206, 235);\n"
""));
        frame_2->setFrameShape(QFrame::Shape::StyledPanel);
        frame_2->setFrameShadow(QFrame::Shadow::Raised);
        label_11 = new QLabel(frame_2);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(120, 80, 411, 61));
        label_11->setStyleSheet(QString::fromUtf8("font: 900 16pt \"Segoe UI\";"));
        pushButton_statistiques = new QPushButton(frame_2);
        pushButton_statistiques->setObjectName("pushButton_statistiques");
        pushButton_statistiques->setGeometry(QRect(180, 180, 221, 71));
        pushButton_statistiques->setStyleSheet(QString::fromUtf8("background-color: #00008B; color: white;\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;"));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName("tab_3");
        label_25 = new QLabel(tab_3);
        label_25->setObjectName("label_25");
        label_25->setGeometry(QRect(330, 10, 921, 161));
        label_25->setPixmap(QPixmap(QString::fromUtf8("../../WhatsApp Image 2025-09-24 at 15.27.43.jpeg")));
        label_6 = new QLabel(tab_3);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(10, 20, 291, 51));
        label_6->setStyleSheet(QString::fromUtf8("font: 900 16pt \"Segoe UI\";"));
        widget = new QWidget(tab_3);
        widget->setObjectName("widget");
        widget->setGeometry(QRect(650, 260, 591, 441));
        widget->setStyleSheet(QString::fromUtf8("background-color: rgb(135, 206, 235);"));
        label_23 = new QLabel(widget);
        label_23->setObjectName("label_23");
        label_23->setGeometry(QRect(90, 60, 421, 61));
        label_23->setStyleSheet(QString::fromUtf8("font: 900 16pt \"Segoe UI\";"));
        pushButton_envoyer = new QPushButton(widget);
        pushButton_envoyer->setObjectName("pushButton_envoyer");
        pushButton_envoyer->setGeometry(QRect(130, 270, 201, 51));
        pushButton_envoyer->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        label_24 = new QLabel(widget);
        label_24->setObjectName("label_24");
        label_24->setGeometry(QRect(430, 170, 141, 71));
        label_24->setStyleSheet(QString::fromUtf8("font: 20pt \"Segoe UI\";"));
        lineEdit_id_2 = new QLineEdit(widget);
        lineEdit_id_2->setObjectName("lineEdit_id_2");
        lineEdit_id_2->setGeometry(QRect(150, 180, 241, 41));
        lineEdit_id_2->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        calendrier = new QPushButton(tab_3);
        calendrier->setObjectName("calendrier");
        calendrier->setGeometry(QRect(360, 610, 201, 51));
        calendrier->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        pushButton_mois_precedent = new QPushButton(tab_3);
        pushButton_mois_precedent->setObjectName("pushButton_mois_precedent");
        pushButton_mois_precedent->setGeometry(QRect(20, 170, 181, 51));
        pushButton_mois_precedent->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        pushButton_mois_suivant = new QPushButton(tab_3);
        pushButton_mois_suivant->setObjectName("pushButton_mois_suivant");
        pushButton_mois_suivant->setGeometry(QRect(480, 180, 171, 51));
        pushButton_mois_suivant->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        pushButton_rafraichir_calendrier = new QPushButton(tab_3);
        pushButton_rafraichir_calendrier->setObjectName("pushButton_rafraichir_calendrier");
        pushButton_rafraichir_calendrier->setGeometry(QRect(30, 610, 231, 51));
        pushButton_rafraichir_calendrier->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;  \n"
""));
        label_mois_annee = new QTextEdit(tab_3);
        label_mois_annee->setObjectName("label_mois_annee");
        label_mois_annee->setGeometry(QRect(220, 180, 231, 41));
        addWidget = new QWidget(tab_3);
        addWidget->setObjectName("addWidget");
        addWidget->setGeometry(QRect(30, 240, 491, 351));
        gridLayoutWidget = new QWidget(addWidget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(20, 10, 451, 331));
        gridLayout_calendrier = new QGridLayout(gridLayoutWidget);
        gridLayout_calendrier->setObjectName("gridLayout_calendrier");
        gridLayout_calendrier->setContentsMargins(0, 0, 0, 0);
        tabWidget->addTab(tab_3, QString());
        stack->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName("page_2");
        tabWidget_2 = new QTabWidget(page_2);
        tabWidget_2->setObjectName("tabWidget_2");
        tabWidget_2->setGeometry(QRect(30, 20, 1231, 811));
        tab_12 = new QWidget();
        tab_12->setObjectName("tab_12");
        groupBox_5 = new QGroupBox(tab_12);
        groupBox_5->setObjectName("groupBox_5");
        groupBox_5->setGeometry(QRect(10, 0, 281, 771));
        groupBox_5->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"        font: 900 9pt \"Segoe UI\";\n"
"        font: 900 9pt \"Segoe UI\";\n"
"        font: 16pt \"Segoe UI\";\n"
"\n"
"        background-color: rgb(135, 206, 235);\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;\n"
"}\n"
"QPushButton {\n"
"    background-color: #4682B4;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5A9BD5;\n"
"}"));
        label_87 = new QLabel(groupBox_5);
        label_87->setObjectName("label_87");
        label_87->setGeometry(QRect(20, 60, 161, 31));
        label_87->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_24 = new QLineEdit(groupBox_5);
        lineEdit_24->setObjectName("lineEdit_24");
        lineEdit_24->setGeometry(QRect(40, 100, 161, 26));
        label_88 = new QLabel(groupBox_5);
        label_88->setObjectName("label_88");
        label_88->setGeometry(QRect(40, 140, 141, 20));
        label_88->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_25 = new QLineEdit(groupBox_5);
        lineEdit_25->setObjectName("lineEdit_25");
        lineEdit_25->setGeometry(QRect(40, 180, 161, 26));
        label_89 = new QLabel(groupBox_5);
        label_89->setObjectName("label_89");
        label_89->setGeometry(QRect(50, 220, 111, 20));
        label_89->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_26 = new QLineEdit(groupBox_5);
        lineEdit_26->setObjectName("lineEdit_26");
        lineEdit_26->setGeometry(QRect(50, 260, 151, 26));
        label_90 = new QLabel(groupBox_5);
        label_90->setObjectName("label_90");
        label_90->setGeometry(QRect(50, 310, 121, 20));
        label_90->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_27 = new QLineEdit(groupBox_5);
        lineEdit_27->setObjectName("lineEdit_27");
        lineEdit_27->setGeometry(QRect(50, 360, 161, 26));
        label_91 = new QLabel(groupBox_5);
        label_91->setObjectName("label_91");
        label_91->setGeometry(QRect(40, 420, 201, 20));
        label_91->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_28 = new QLineEdit(groupBox_5);
        lineEdit_28->setObjectName("lineEdit_28");
        lineEdit_28->setGeometry(QRect(50, 460, 161, 31));
        label_92 = new QLabel(groupBox_5);
        label_92->setObjectName("label_92");
        label_92->setGeometry(QRect(30, 500, 211, 31));
        label_92->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        lineEdit_29 = new QLineEdit(groupBox_5);
        lineEdit_29->setObjectName("lineEdit_29");
        lineEdit_29->setGeometry(QRect(90, 550, 161, 31));
        label_93 = new QLabel(groupBox_5);
        label_93->setObjectName("label_93");
        label_93->setGeometry(QRect(30, 600, 231, 31));
        label_93->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        dateEdit_5 = new QDateEdit(groupBox_5);
        dateEdit_5->setObjectName("dateEdit_5");
        dateEdit_5->setGeometry(QRect(40, 650, 171, 26));
        dateEdit_5->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        pushButton_26 = new QPushButton(groupBox_5);
        pushButton_26->setObjectName("pushButton_26");
        pushButton_26->setGeometry(QRect(120, 720, 93, 29));
        label_94 = new QLabel(groupBox_5);
        label_94->setObjectName("label_94");
        label_94->setGeometry(QRect(40, 550, 61, 21));
        label_94->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        tableWidget_5 = new QTableWidget(tab_12);
        if (tableWidget_5->columnCount() < 7)
            tableWidget_5->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        QTableWidgetItem *__qtablewidgetitem4 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(4, __qtablewidgetitem4);
        QTableWidgetItem *__qtablewidgetitem5 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(5, __qtablewidgetitem5);
        QTableWidgetItem *__qtablewidgetitem6 = new QTableWidgetItem();
        tableWidget_5->setHorizontalHeaderItem(6, __qtablewidgetitem6);
        tableWidget_5->setObjectName("tableWidget_5");
        tableWidget_5->setGeometry(QRect(300, 190, 941, 471));
        tableWidget_5->setStyleSheet(QString::fromUtf8("background-color: #00008B;   /* \330\243\330\262\330\261\331\202 \330\272\330\247\331\205\331\202 */\n"
"    color: white;                /* \330\247\331\204\331\206\330\265 \330\243\330\250\331\212\330\266 */\n"
"    gridline-color: white;       /* \331\204\331\210\331\206 \330\247\331\204\330\256\330\267\331\210\330\267 */\n"
"    border-radius: 8px;          /* \330\255\331\210\330\247\331\201 \331\205\330\263\330\252\330\257\331\212\330\261\330\251 */\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: #34495e;   /* \330\261\331\205\330\247\330\257\331\212 \330\272\330\247\331\205\331\202 \331\204\331\204\331\200 header */\n"
"    color: white;\n"
"    padding: 4px;\n"
"    border: 1px solid #2c3e50;\n"
""));
        tableWidget_5->horizontalHeader()->setStretchLastSection(true);
        tableWidget_5->verticalHeader()->setProperty("showSortIndicator", QVariant(true));
        tableWidget_5->verticalHeader()->setStretchLastSection(false);
        label_95 = new QLabel(tab_12);
        label_95->setObjectName("label_95");
        label_95->setGeometry(QRect(490, 60, 521, 61));
        label_95->setStyleSheet(QString::fromUtf8("\n"
"font: 48pt \"Segoe UI\";"));
        pushButton_27 = new QPushButton(tab_12);
        pushButton_27->setObjectName("pushButton_27");
        pushButton_27->setGeometry(QRect(640, 130, 151, 51));
        pushButton_27->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;"));
        lineEdit_30 = new QLineEdit(tab_12);
        lineEdit_30->setObjectName("lineEdit_30");
        lineEdit_30->setGeometry(QRect(490, 140, 141, 31));
        label_96 = new QLabel(tab_12);
        label_96->setObjectName("label_96");
        label_96->setGeometry(QRect(330, 140, 171, 31));
        pushButton_28 = new QPushButton(tab_12);
        pushButton_28->setObjectName("pushButton_28");
        pushButton_28->setGeometry(QRect(870, 680, 171, 41));
        pushButton_28->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;"));
        lineEdit_31 = new QLineEdit(tab_12);
        lineEdit_31->setObjectName("lineEdit_31");
        lineEdit_31->setGeometry(QRect(720, 690, 131, 31));
        label_97 = new QLabel(tab_12);
        label_97->setObjectName("label_97");
        label_97->setGeometry(QRect(530, 690, 181, 31));
        label_98 = new QLabel(tab_12);
        label_98->setObjectName("label_98");
        label_98->setGeometry(QRect(800, 140, 91, 31));
        comboBox_8 = new QComboBox(tab_12);
        comboBox_8->addItem(QString());
        comboBox_8->addItem(QString());
        comboBox_8->addItem(QString());
        comboBox_8->setObjectName("comboBox_8");
        comboBox_8->setGeometry(QRect(880, 140, 76, 31));
        pushButton_29 = new QPushButton(tab_12);
        pushButton_29->setObjectName("pushButton_29");
        pushButton_29->setGeometry(QRect(340, 690, 171, 41));
        pushButton_29->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;"));
        checkBox_27 = new QCheckBox(tab_12);
        checkBox_27->setObjectName("checkBox_27");
        checkBox_27->setGeometry(QRect(1270, 470, 91, 24));
        tabWidget_2->addTab(tab_12, QString());
        tab_13 = new QWidget();
        tab_13->setObjectName("tab_13");
        verticalLayout_stat = new QVBoxLayout(tab_13);
        verticalLayout_stat->setContentsMargins(10, 10, 10, 10);
        verticalLayout_stat->setObjectName("verticalLayout_stat");
        tabWidget_2->addTab(tab_13, QString());
        stack->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName("page_3");
        tabWidget_3 = new QTabWidget(page_3);
        tabWidget_3->setObjectName("tabWidget_3");
        tabWidget_3->setGeometry(QRect(10, 20, 1256, 781));
        tabWidget_3->setStyleSheet(QString::fromUtf8("color: rgb(18, 18, 18);\n"
"background-color: rgb(255, 255, 255);"));
        tabWidget_3->setTabsClosable(false);
        tabWidget_3->setTabBarAutoHide(true);
        tab_crud = new QWidget();
        tab_crud->setObjectName("tab_crud");
        horizontalLayout = new QHBoxLayout(tab_crud);
        horizontalLayout->setObjectName("horizontalLayout");
        frameAjout = new QFrame(tab_crud);
        frameAjout->setObjectName("frameAjout");
        frameAjout->setMinimumSize(QSize(300, 0));
        frameAjout->setMaximumSize(QSize(300, 16777215));
        frameAjout->setStyleSheet(QString::fromUtf8("QFrame#frameAjout {\n"
"    background-color: rgb(135, 206, 235);\n"
"    border-radius: 10px;\n"
"    padding: 10px;\n"
"}"));
        frameAjout->setFrameShape(QFrame::Shape::StyledPanel);
        verticalLayout = new QVBoxLayout(frameAjout);
        verticalLayout->setObjectName("verticalLayout");
        labelTitre = new QLabel(frameAjout);
        labelTitre->setObjectName("labelTitre");
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        labelTitre->setFont(font);
        labelTitre->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelTitre);

        labelNom = new QLabel(frameAjout);
        labelNom->setObjectName("labelNom");
        labelNom->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelNom);

        lineEditNom = new QLineEdit(frameAjout);
        lineEditNom->setObjectName("lineEditNom");
        lineEditNom->setMinimumSize(QSize(0, 30));
        lineEditNom->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditNom);

        labelPrenom = new QLabel(frameAjout);
        labelPrenom->setObjectName("labelPrenom");
        labelPrenom->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelPrenom);

        lineEditPrenom = new QLineEdit(frameAjout);
        lineEditPrenom->setObjectName("lineEditPrenom");
        lineEditPrenom->setMinimumSize(QSize(0, 30));
        lineEditPrenom->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditPrenom);

        labelCIN = new QLabel(frameAjout);
        labelCIN->setObjectName("labelCIN");
        labelCIN->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelCIN);

        lineEditCIN = new QLineEdit(frameAjout);
        lineEditCIN->setObjectName("lineEditCIN");
        lineEditCIN->setMinimumSize(QSize(0, 30));
        lineEditCIN->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditCIN);

        labelPoste = new QLabel(frameAjout);
        labelPoste->setObjectName("labelPoste");
        labelPoste->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelPoste);

        jjj = new QDateEdit(frameAjout);
        jjj->setObjectName("jjj");
        jjj->setMinimumSize(QSize(0, 30));
        jjj->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
""));
        jjj->setCalendarPopup(true);
        jjj->setDate(QDate(2000, 1, 1));

        verticalLayout->addWidget(jjj);

        labelMotDePasse = new QLabel(frameAjout);
        labelMotDePasse->setObjectName("labelMotDePasse");
        labelMotDePasse->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelMotDePasse);

        lineEditMotDePasse = new QLineEdit(frameAjout);
        lineEditMotDePasse->setObjectName("lineEditMotDePasse");
        lineEditMotDePasse->setMinimumSize(QSize(0, 30));
        lineEditMotDePasse->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditMotDePasse);

        labelTelephone = new QLabel(frameAjout);
        labelTelephone->setObjectName("labelTelephone");
        labelTelephone->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelTelephone);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName("horizontalLayout_2");
        labelIndicatif = new QLabel(frameAjout);
        labelIndicatif->setObjectName("labelIndicatif");
        labelIndicatif->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        horizontalLayout_2->addWidget(labelIndicatif);

        lineEditTelephone = new QLineEdit(frameAjout);
        lineEditTelephone->setObjectName("lineEditTelephone");
        lineEditTelephone->setMinimumSize(QSize(0, 30));
        lineEditTelephone->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        horizontalLayout_2->addWidget(lineEditTelephone);


        verticalLayout->addLayout(horizontalLayout_2);

        labelDateEmbauche = new QLabel(frameAjout);
        labelDateEmbauche->setObjectName("labelDateEmbauche");
        labelDateEmbauche->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelDateEmbauche);

        lineEditPoste = new QLineEdit(frameAjout);
        lineEditPoste->setObjectName("lineEditPoste");
        lineEditPoste->setMinimumSize(QSize(0, 30));
        lineEditPoste->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditPoste);

        labelLatitude = new QLabel(frameAjout);
        labelLatitude->setObjectName("labelLatitude");
        labelLatitude->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelLatitude);

        lineEditLatitude = new QLineEdit(frameAjout);
        lineEditLatitude->setObjectName("lineEditLatitude");
        lineEditLatitude->setMinimumSize(QSize(0, 30));
        lineEditLatitude->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditLatitude);

        labelLongitude = new QLabel(frameAjout);
        labelLongitude->setObjectName("labelLongitude");
        labelLongitude->setStyleSheet(QString::fromUtf8("color: rgb(6, 6, 6);\n"
""));

        verticalLayout->addWidget(labelLongitude);

        lineEditLongitude = new QLineEdit(frameAjout);
        lineEditLongitude->setObjectName("lineEditLongitude");
        lineEditLongitude->setMinimumSize(QSize(0, 30));
        lineEditLongitude->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);"));

        verticalLayout->addWidget(lineEditLongitude);

        verticalSpacer_8 = new QSpacerItem(20, 20, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout->addItem(verticalSpacer_8);

        btnAjouter = new QPushButton(frameAjout);
        btnAjouter->setObjectName("btnAjouter");
        btnAjouter->setMinimumSize(QSize(0, 40));
        QFont font1;
        font1.setPointSize(11);
        font1.setBold(true);
        btnAjouter->setFont(font1);
        btnAjouter->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(95, 158, 160);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(74, 122, 124);\n"
"}"));

        verticalLayout->addWidget(btnAjouter);

        btnModifier = new QPushButton(frameAjout);
        btnModifier->setObjectName("btnModifier");
        btnModifier->setMinimumSize(QSize(0, 40));
        btnModifier->setFont(font1);
        btnModifier->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(95, 158, 160);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(74, 122, 124);\n"
"}"));

        verticalLayout->addWidget(btnModifier);

        verticalSpacer_9 = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        verticalLayout->addItem(verticalSpacer_9);


        horizontalLayout->addWidget(frameAjout);

        widgetGestion = new QWidget(tab_crud);
        widgetGestion->setObjectName("widgetGestion");
        widgetGestion->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        verticalLayout_2 = new QVBoxLayout(widgetGestion);
        verticalLayout_2->setObjectName("verticalLayout_2");
        labelGestion = new QLabel(widgetGestion);
        labelGestion->setObjectName("labelGestion");
        QFont font2;
        font2.setPointSize(18);
        font2.setBold(true);
        labelGestion->setFont(font2);
        labelGestion->setStyleSheet(QString::fromUtf8("color: rgb(12, 12, 12);"));

        verticalLayout_2->addWidget(labelGestion);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName("horizontalLayout_3");
        labelAfficher = new QLabel(widgetGestion);
        labelAfficher->setObjectName("labelAfficher");
        labelAfficher->setStyleSheet(QString::fromUtf8("color: rgb(11, 11, 11);"));

        horizontalLayout_3->addWidget(labelAfficher);

        lineEditRecherche = new QLineEdit(widgetGestion);
        lineEditRecherche->setObjectName("lineEditRecherche");
        lineEditRecherche->setMinimumSize(QSize(250, 35));

        horizontalLayout_3->addWidget(lineEditRecherche);

        btnChercher = new QPushButton(widgetGestion);
        btnChercher->setObjectName("btnChercher");
        btnChercher->setMinimumSize(QSize(120, 40));
        btnChercher->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(70, 130, 180);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(54, 100, 139);\n"
"}"));

        horizontalLayout_3->addWidget(btnChercher);

        btnClear = new QPushButton(widgetGestion);
        btnClear->setObjectName("btnClear");
        btnClear->setMinimumSize(QSize(120, 40));
        btnClear->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(220, 20, 60);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(178, 34, 34);\n"
"}"));

        horizontalLayout_3->addWidget(btnClear);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        labelTrier = new QLabel(widgetGestion);
        labelTrier->setObjectName("labelTrier");

        horizontalLayout_3->addWidget(labelTrier);

        comboBoxTrier = new QComboBox(widgetGestion);
        comboBoxTrier->addItem(QString());
        comboBoxTrier->addItem(QString());
        comboBoxTrier->setObjectName("comboBoxTrier");
        comboBoxTrier->setMinimumSize(QSize(120, 35));

        horizontalLayout_3->addWidget(comboBoxTrier);


        verticalLayout_2->addLayout(horizontalLayout_3);

        tableWidget_6 = new QTableWidget(widgetGestion);
        if (tableWidget_6->columnCount() < 7)
            tableWidget_6->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem7 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(0, __qtablewidgetitem7);
        QTableWidgetItem *__qtablewidgetitem8 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(1, __qtablewidgetitem8);
        QTableWidgetItem *__qtablewidgetitem9 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(2, __qtablewidgetitem9);
        QTableWidgetItem *__qtablewidgetitem10 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(3, __qtablewidgetitem10);
        QTableWidgetItem *__qtablewidgetitem11 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(4, __qtablewidgetitem11);
        QTableWidgetItem *__qtablewidgetitem12 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(5, __qtablewidgetitem12);
        QTableWidgetItem *__qtablewidgetitem13 = new QTableWidgetItem();
        tableWidget_6->setHorizontalHeaderItem(6, __qtablewidgetitem13);
        tableWidget_6->setObjectName("tableWidget_6");
        tableWidget_6->setStyleSheet(QString::fromUtf8("QTableWidget {\n"
"    background-color: rgb(0, 0, 139);\n"
"    color: white;\n"
"    gridline-color: rgb(65, 105, 225);\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: rgb(47, 79, 79);\n"
"    color: white;\n"
"    padding: 5px;\n"
"    font-weight: bold;\n"
"}\n"
"QTableWidget::item:selected {\n"
"    background-color: rgb(30, 144, 255);\n"
"}"));

        verticalLayout_2->addWidget(tableWidget_6);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName("horizontalLayout_4");
        labelSupprimer = new QLabel(widgetGestion);
        labelSupprimer->setObjectName("labelSupprimer");

        horizontalLayout_4->addWidget(labelSupprimer);

        lineEditSupprimer = new QLineEdit(widgetGestion);
        lineEditSupprimer->setObjectName("lineEditSupprimer");
        lineEditSupprimer->setMinimumSize(QSize(250, 35));

        horizontalLayout_4->addWidget(lineEditSupprimer);

        btnGenererQRClient = new QPushButton(widgetGestion);
        btnGenererQRClient->setObjectName("btnGenererQRClient");
        btnGenererQRClient->setMinimumSize(QSize(120, 40));
        btnGenererQRClient->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(70, 130, 180);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(54, 100, 139);\n"
"}\n"
""));

        horizontalLayout_4->addWidget(btnGenererQRClient);

        btnExporterPDF = new QPushButton(widgetGestion);
        btnExporterPDF->setObjectName("btnExporterPDF");
        btnExporterPDF->setMinimumSize(QSize(120, 40));
        btnExporterPDF->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(34, 139, 34);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(0, 100, 0);\n"
"}\n"
""));

        horizontalLayout_4->addWidget(btnExporterPDF);

        btnSupprimer = new QPushButton(widgetGestion);
        btnSupprimer->setObjectName("btnSupprimer");
        btnSupprimer->setMinimumSize(QSize(120, 40));
        btnSupprimer->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(70, 130, 180);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(54, 100, 139);\n"
"}"));

        horizontalLayout_4->addWidget(btnSupprimer);


        verticalLayout_2->addLayout(horizontalLayout_4);


        horizontalLayout->addWidget(widgetGestion);

        tabWidget_3->addTab(tab_crud, QString());
        tab_ajouter = new QWidget();
        tab_ajouter->setObjectName("tab_ajouter");
        verticalLayout_3 = new QVBoxLayout(tab_ajouter);
        verticalLayout_3->setObjectName("verticalLayout_3");
        tabWidget_3->addTab(tab_ajouter, QString());
        tab_14 = new QWidget();
        tab_14->setObjectName("tab_14");
        label_102 = new QLabel(tab_14);
        label_102->setObjectName("label_102");
        label_102->setGeometry(QRect(340, 10, 651, 601));
        label_102->setPixmap(QPixmap(QString::fromUtf8("../../WhatsApp Image 2025-10-04 at 14.58.41.jpeg")));
        label_103 = new QLabel(tab_14);
        label_103->setObjectName("label_103");
        label_103->setGeometry(QRect(90, 170, 181, 131));
        label_103->setStyleSheet(QString::fromUtf8("font: 20pt \"Segoe UI\";"));
        labelClientMapSearch = new QLabel(tab_14);
        labelClientMapSearch->setObjectName("labelClientMapSearch");
        labelClientMapSearch->setGeometry(QRect(60, 320, 260, 30));
        lineEditClientMapSearch = new QLineEdit(tab_14);
        lineEditClientMapSearch->setObjectName("lineEditClientMapSearch");
        lineEditClientMapSearch->setGeometry(QRect(60, 360, 260, 30));
        btnShowClientOnMap = new QPushButton(tab_14);
        btnShowClientOnMap->setObjectName("btnShowClientOnMap");
        btnShowClientOnMap->setGeometry(QRect(60, 410, 260, 40));
        btnShowClientOnMap->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    background-color: rgb(46, 139, 87);\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: rgb(34, 139, 34);\n"
"}"));
        clientMapContainer = new QWidget(tab_14);
        clientMapContainer->setObjectName("clientMapContainer");
        clientMapContainer->setGeometry(QRect(360, 40, 620, 520));
        clientMapContainer->setStyleSheet(QString::fromUtf8("background-color: rgb(15, 30, 50); border-radius: 10px;"));
        tabWidget_3->addTab(tab_14, QString());
        stack->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName("page_4");
        tabWidget_4 = new QTabWidget(page_4);
        tabWidget_4->setObjectName("tabWidget_4");
        tabWidget_4->setGeometry(QRect(10, 20, 1241, 811));
        tabWidget_4->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        tabAcceuil = new QWidget();
        tabAcceuil->setObjectName("tabAcceuil");
        labelTitre_2 = new QLabel(tabAcceuil);
        labelTitre_2->setObjectName("labelTitre_2");
        labelTitre_2->setGeometry(QRect(680, -10, 471, 61));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Segoe UI")});
        font3.setPointSize(16);
        font3.setBold(false);
        font3.setItalic(false);
        labelTitre_2->setFont(font3);
        labelTitre_2->setStyleSheet(QString::fromUtf8("font: 16pt \"Segoe UI\";"));
        groupBoxAjout = new QGroupBox(tabAcceuil);
        groupBoxAjout->setObjectName("groupBoxAjout");
        groupBoxAjout->setGeometry(QRect(0, 0, 351, 741));
        groupBoxAjout->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"        font: 900 9pt \"Segoe UI\";\n"
"        font: 900 9pt \"Segoe UI\";\n"
"        font: 16pt \"Segoe UI\";\n"
"\n"
"        background-color: rgb(135, 206, 235);\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;\n"
"}\n"
"QPushButton {\n"
"    background-color: #4682B4;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5A9BD5;\n"
"}"));
        labelImmatricule = new QLabel(groupBoxAjout);
        labelImmatricule->setObjectName("labelImmatricule");
        labelImmatricule->setGeometry(QRect(20, 80, 201, 31));
        QFont font4;
        font4.setFamilies({QString::fromUtf8("Segoe UI")});
        font4.setPointSize(12);
        font4.setBold(false);
        font4.setItalic(false);
        labelImmatricule->setFont(font4);
        lineEdit_immatricule_2 = new QLineEdit(groupBoxAjout);
        lineEdit_immatricule_2->setObjectName("lineEdit_immatricule_2");
        lineEdit_immatricule_2->setGeometry(QRect(40, 120, 171, 31));
        labelModele = new QLabel(groupBoxAjout);
        labelModele->setObjectName("labelModele");
        labelModele->setGeometry(QRect(20, 170, 171, 21));
        labelModele->setFont(font4);
        lineEdit_modele = new QLineEdit(groupBoxAjout);
        lineEdit_modele->setObjectName("lineEdit_modele");
        lineEdit_modele->setGeometry(QRect(40, 200, 171, 31));
        labelType = new QLabel(groupBoxAjout);
        labelType->setObjectName("labelType");
        labelType->setGeometry(QRect(30, 250, 121, 31));
        labelType->setFont(font4);
        comboBox_type_2 = new QComboBox(groupBoxAjout);
        comboBox_type_2->addItem(QString());
        comboBox_type_2->addItem(QString());
        comboBox_type_2->addItem(QString());
        comboBox_type_2->setObjectName("comboBox_type_2");
        comboBox_type_2->setGeometry(QRect(50, 290, 161, 31));
        pushButton_validervehicule = new QPushButton(groupBoxAjout);
        pushButton_validervehicule->setObjectName("pushButton_validervehicule");
        pushButton_validervehicule->setGeometry(QRect(10, 580, 121, 41));
        pushButton_validervehicule->setFont(font4);
        pushButton_modifiervehicule = new QPushButton(groupBoxAjout);
        pushButton_modifiervehicule->setObjectName("pushButton_modifiervehicule");
        pushButton_modifiervehicule->setGeometry(QRect(210, 580, 111, 41));
        pushButton_modifiervehicule->setFont(font4);
        dateEdit_assurance = new QDateEdit(groupBoxAjout);
        dateEdit_assurance->setObjectName("dateEdit_assurance");
        dateEdit_assurance->setGeometry(QRect(40, 540, 161, 31));
        label_104 = new QLabel(groupBoxAjout);
        label_104->setObjectName("label_104");
        label_104->setGeometry(QRect(30, 510, 241, 20));
        label_104->setFont(font4);
        comboBox_etat = new QComboBox(groupBoxAjout);
        comboBox_etat->addItem(QString());
        comboBox_etat->addItem(QString());
        comboBox_etat->setObjectName("comboBox_etat");
        comboBox_etat->setGeometry(QRect(40, 470, 201, 31));
        label_105 = new QLabel(groupBoxAjout);
        label_105->setObjectName("label_105");
        label_105->setGeometry(QRect(30, 420, 101, 41));
        label_105->setFont(font4);
        comboBox_transmission = new QComboBox(groupBoxAjout);
        comboBox_transmission->addItem(QString());
        comboBox_transmission->addItem(QString());
        comboBox_transmission->setObjectName("comboBox_transmission");
        comboBox_transmission->setGeometry(QRect(50, 380, 161, 31));
        label_106 = new QLabel(groupBoxAjout);
        label_106->setObjectName("label_106");
        label_106->setGeometry(QRect(30, 340, 181, 31));
        label_106->setFont(font4);
        lineEdit_rechercheVehicule = new QLineEdit(tabAcceuil);
        lineEdit_rechercheVehicule->setObjectName("lineEdit_rechercheVehicule");
        lineEdit_rechercheVehicule->setGeometry(QRect(460, 50, 261, 30));
        pushButton_exporterVehicule = new QPushButton(tabAcceuil);
        pushButton_exporterVehicule->setObjectName("pushButton_exporterVehicule");
        pushButton_exporterVehicule->setGeometry(QRect(430, 520, 201, 41));
        pushButton_exporterVehicule->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;"));
        pushButton_rechercheVehicule = new QPushButton(tabAcceuil);
        pushButton_rechercheVehicule->setObjectName("pushButton_rechercheVehicule");
        pushButton_rechercheVehicule->setGeometry(QRect(740, 50, 111, 41));
        pushButton_rechercheVehicule->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;\n"
""));
        label_107 = new QLabel(tabAcceuil);
        label_107->setObjectName("label_107");
        label_107->setGeometry(QRect(870, 50, 151, 31));
        QFont font5;
        font5.setFamilies({QString::fromUtf8("Segoe UI")});
        font5.setPointSize(14);
        font5.setBold(false);
        font5.setItalic(false);
        label_107->setFont(font5);
        label_107->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        comboBox_trierVehicule = new QComboBox(tabAcceuil);
        comboBox_trierVehicule->addItem(QString());
        comboBox_trierVehicule->addItem(QString());
        comboBox_trierVehicule->addItem(QString());
        comboBox_trierVehicule->setObjectName("comboBox_trierVehicule");
        comboBox_trierVehicule->setGeometry(QRect(1030, 50, 161, 41));
        pushButton_supprimervehicule = new QPushButton(tabAcceuil);
        pushButton_supprimervehicule->setObjectName("pushButton_supprimervehicule");
        pushButton_supprimervehicule->setGeometry(QRect(900, 530, 171, 41));
        pushButton_supprimervehicule->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;"));
        lineEdit_32 = new QLineEdit(tabAcceuil);
        lineEdit_32->setObjectName("lineEdit_32");
        lineEdit_32->setGeometry(QRect(710, 540, 171, 31));
        tableView_vehicules = new QTableView(tabAcceuil);
        tableView_vehicules->setObjectName("tableView_vehicules");
        tableView_vehicules->setGeometry(QRect(380, 100, 841, 371));
        tabWidget_4->addTab(tabAcceuil, QString());
        tableView_vehicules->raise();
        labelTitre_2->raise();
        groupBoxAjout->raise();
        lineEdit_rechercheVehicule->raise();
        pushButton_exporterVehicule->raise();
        pushButton_rechercheVehicule->raise();
        label_107->raise();
        comboBox_trierVehicule->raise();
        pushButton_supprimervehicule->raise();
        lineEdit_32->raise();
        tabStats = new QWidget();
        tabStats->setObjectName("tabStats");
        label_109 = new QLabel(tabStats);
        label_109->setObjectName("label_109");
        label_109->setGeometry(QRect(20, 100, 261, 211));
        label_109->setPixmap(QPixmap(QString::fromUtf8("../driving123 - Copie/Users/z/Downloads/20180115104702a29a23-Sans-titre-1-253x290.jpg")));
        label_110 = new QLabel(tabStats);
        label_110->setObjectName("label_110");
        label_110->setGeometry(QRect(300, 30, 651, 471));
        label_110->setPixmap(QPixmap(QString::fromUtf8("../driving123 - Copie/Users/z/Downloads/diagrame.png")));
        pushButton_statistiques_2 = new QPushButton(tabStats);
        pushButton_statistiques_2->setObjectName("pushButton_statistiques_2");
        pushButton_statistiques_2->setGeometry(QRect(350, 250, 161, 81));
        pushButton_statistiques_2->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 16pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */\n"
"    border-radius: 12px;         /* \330\247\331\204\330\255\331\210\330\247\331\201 \331\205\330\257\331\210\331\221\330\261\330\251 */\n"
"    padding: 8px 16px;\n"
""));
        label_27 = new QLabel(tabStats);
        label_27->setObjectName("label_27");
        label_27->setGeometry(QRect(270, 60, 351, 41));
        label_27->setStyleSheet(QString::fromUtf8("font: 20pt \"Segoe UI\";\n"
"font: 900 20pt \"Segoe UI\";\n"
"\n"
"    color: noir;                /* \331\204\331\210\331\206 \330\247\331\204\331\206\330\265 */"));
        tabWidget_4->addTab(tabStats, QString());
        tab_15 = new QWidget();
        tab_15->setObjectName("tab_15");
        groupBox_6 = new QGroupBox(tab_15);
        groupBox_6->setObjectName("groupBox_6");
        groupBox_6->setGeometry(QRect(20, 100, 531, 511));
        groupBox_6->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"        font: 900 29pt \"Segoe UI\";\n"
"        font: 900 29pt \"Segoe UI\";\n"
"        font: 20pt \"Segoe UI\";\n"
"\n"
"        background-color: rgb(135, 206, 235);\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;\n"
"}\n"
"QPushButton {\n"
"    background-color: #4682B4;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5A9BD5;\n"
"}\n"
""));
        tableWidget_assurance = new QTableWidget(groupBox_6);
        if (tableWidget_assurance->columnCount() < 3)
            tableWidget_assurance->setColumnCount(3);
        QTableWidgetItem *__qtablewidgetitem14 = new QTableWidgetItem();
        tableWidget_assurance->setHorizontalHeaderItem(0, __qtablewidgetitem14);
        QTableWidgetItem *__qtablewidgetitem15 = new QTableWidgetItem();
        tableWidget_assurance->setHorizontalHeaderItem(1, __qtablewidgetitem15);
        QTableWidgetItem *__qtablewidgetitem16 = new QTableWidgetItem();
        tableWidget_assurance->setHorizontalHeaderItem(2, __qtablewidgetitem16);
        tableWidget_assurance->setObjectName("tableWidget_assurance");
        tableWidget_assurance->setGeometry(QRect(30, 70, 441, 301));
        label_expired = new QLabel(groupBox_6);
        label_expired->setObjectName("label_expired");
        label_expired->setGeometry(QRect(60, 410, 161, 16));
        label_soon = new QLabel(groupBox_6);
        label_soon->setObjectName("label_soon");
        label_soon->setGeometry(QRect(60, 440, 171, 16));
        groupBox_7 = new QGroupBox(tab_15);
        groupBox_7->setObjectName("groupBox_7");
        groupBox_7->setGeometry(QRect(630, 110, 561, 501));
        groupBox_7->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"        font: 900 29pt \"Segoe UI\";\n"
"        font: 900 29pt \"Segoe UI\";\n"
"        font: 20pt \"Segoe UI\";\n"
"\n"
"        background-color: rgb(135, 206, 235);\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;\n"
"}\n"
"QPushButton {\n"
"    background-color: #4682B4;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5A9BD5;\n"
"}"));
        pushButton_historique = new QPushButton(groupBox_7);
        pushButton_historique->setObjectName("pushButton_historique");
        pushButton_historique->setGeometry(QRect(190, 200, 151, 81));
        tabWidget_4->addTab(tab_15, QString());
        stack->addWidget(page_4);
        page_5 = new QWidget();
        page_5->setObjectName("page_5");
        contratsTabWidget = new QTabWidget(page_5);
        contratsTabWidget->setObjectName("contratsTabWidget");
        contratsTabWidget->setGeometry(QRect(10, 10, 1251, 801));
        contratsTabWidget->setStyleSheet(QString::fromUtf8("color:rgb(70, 130, 180);"));
        displayTab = new QWidget();
        displayTab->setObjectName("displayTab");
        displayLayout = new QVBoxLayout(displayTab);
        displayLayout->setSpacing(15);
        displayLayout->setObjectName("displayLayout");
        displayLayout->setContentsMargins(20, 20, 20, 20);
        toolbarLayout = new QHBoxLayout();
        toolbarLayout->setObjectName("toolbarLayout");
        searchEdit = new QLineEdit(displayTab);
        searchEdit->setObjectName("searchEdit");

        toolbarLayout->addWidget(searchEdit);

        stat = new QPushButton(displayTab);
        stat->setObjectName("stat");

        toolbarLayout->addWidget(stat);

        searchBtn = new QPushButton(displayTab);
        searchBtn->setObjectName("searchBtn");
        searchBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        toolbarLayout->addWidget(searchBtn);

        sortBtn = new QPushButton(displayTab);
        sortBtn->setObjectName("sortBtn");
        sortBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        toolbarLayout->addWidget(sortBtn);

        toolbarSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        toolbarLayout->addItem(toolbarSpacer);

        exportPdfBtnMoniteur = new QPushButton(displayTab);
        exportPdfBtnMoniteur->setObjectName("exportPdfBtnMoniteur");
        exportPdfBtnMoniteur->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        toolbarLayout->addWidget(exportPdfBtnMoniteur);


        displayLayout->addLayout(toolbarLayout);

        moniteurTable = new QTableWidget(displayTab);
        if (moniteurTable->columnCount() < 7)
            moniteurTable->setColumnCount(7);
        QTableWidgetItem *__qtablewidgetitem17 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(0, __qtablewidgetitem17);
        QTableWidgetItem *__qtablewidgetitem18 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(1, __qtablewidgetitem18);
        QTableWidgetItem *__qtablewidgetitem19 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(2, __qtablewidgetitem19);
        QTableWidgetItem *__qtablewidgetitem20 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(3, __qtablewidgetitem20);
        QTableWidgetItem *__qtablewidgetitem21 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(4, __qtablewidgetitem21);
        QTableWidgetItem *__qtablewidgetitem22 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(5, __qtablewidgetitem22);
        QTableWidgetItem *__qtablewidgetitem23 = new QTableWidgetItem();
        moniteurTable->setHorizontalHeaderItem(6, __qtablewidgetitem23);
        moniteurTable->setObjectName("moniteurTable");
        moniteurTable->setStyleSheet(QString::fromUtf8("QTableWidget {\n"
"   background-color: #00008B;   /* \330\243\330\262\330\261\331\202 \330\272\330\247\331\205\331\202 */\n"
"    color: white;                /* texte en blanc */\n"
"    gridline-color: #34495e;     /* couleur des lignes */\n"
"    font: 12px \"Poppins\";        /* police si tu veux */\n"
"}\n"
"\n"
"QHeaderView::section {\n"
"    background-color: #2C3E50;   /* en-t\303\252tes en bleu fonc\303\251 plus clair */\n"
"    color: white;\n"
"    font-weight: bold;\n"
"    border: 1px solid #34495e;\n"
"}\n"
"\n"
"QTableWidget::item:selected {\n"
"    background-color: #2980b9;   /* s\303\251lection plus claire */\n"
"    color: white;\n"
"}\n"
""));
        moniteurTable->setAlternatingRowColors(true);
        moniteurTable->setSelectionBehavior(QAbstractItemView::SelectionBehavior::SelectRows);
        moniteurTable->setSortingEnabled(true);

        displayLayout->addWidget(moniteurTable);

        Modifiermoniteur = new QPushButton(displayTab);
        Modifiermoniteur->setObjectName("Modifiermoniteur");

        displayLayout->addWidget(Modifiermoniteur);

        supprimermoniteur = new QPushButton(displayTab);
        supprimermoniteur->setObjectName("supprimermoniteur");

        displayLayout->addWidget(supprimermoniteur);

        contratsTabWidget->addTab(displayTab, QString());
        modifyTab = new QWidget();
        modifyTab->setObjectName("modifyTab");
        modifyLayout = new QVBoxLayout(modifyTab);
        modifyLayout->setSpacing(15);
        modifyLayout->setObjectName("modifyLayout");
        modifyLayout->setContentsMargins(20, 20, 20, 20);
        modifyFormLayout = new QFormLayout();
        modifyFormLayout->setObjectName("modifyFormLayout");
        modifyIdLabel = new QLabel(modifyTab);
        modifyIdLabel->setObjectName("modifyIdLabel");

        modifyFormLayout->setWidget(0, QFormLayout::LabelRole, modifyIdLabel);

        idmod = new QLineEdit(modifyTab);
        idmod->setObjectName("idmod");
        idmod->setReadOnly(true);

        modifyFormLayout->setWidget(0, QFormLayout::FieldRole, idmod);

        modifyNameLabel = new QLabel(modifyTab);
        modifyNameLabel->setObjectName("modifyNameLabel");

        modifyFormLayout->setWidget(1, QFormLayout::LabelRole, modifyNameLabel);

        cinmod = new QLineEdit(modifyTab);
        cinmod->setObjectName("cinmod");

        modifyFormLayout->setWidget(1, QFormLayout::FieldRole, cinmod);

        modifyEmailLabel = new QLabel(modifyTab);
        modifyEmailLabel->setObjectName("modifyEmailLabel");

        modifyFormLayout->setWidget(2, QFormLayout::LabelRole, modifyEmailLabel);

        nommod = new QLineEdit(modifyTab);
        nommod->setObjectName("nommod");

        modifyFormLayout->setWidget(2, QFormLayout::FieldRole, nommod);

        modifyPhoneLabel = new QLabel(modifyTab);
        modifyPhoneLabel->setObjectName("modifyPhoneLabel");

        modifyFormLayout->setWidget(3, QFormLayout::LabelRole, modifyPhoneLabel);

        prenommod = new QLineEdit(modifyTab);
        prenommod->setObjectName("prenommod");

        modifyFormLayout->setWidget(3, QFormLayout::FieldRole, prenommod);

        modifyCompanyLabel = new QLabel(modifyTab);
        modifyCompanyLabel->setObjectName("modifyCompanyLabel");

        modifyFormLayout->setWidget(4, QFormLayout::LabelRole, modifyCompanyLabel);

        telmod = new QLineEdit(modifyTab);
        telmod->setObjectName("telmod");

        modifyFormLayout->setWidget(4, QFormLayout::FieldRole, telmod);

        permismod = new QLineEdit(modifyTab);
        permismod->setObjectName("permismod");

        modifyFormLayout->setWidget(6, QFormLayout::FieldRole, permismod);

        emailmod = new QLineEdit(modifyTab);
        emailmod->setObjectName("emailmod");

        modifyFormLayout->setWidget(5, QFormLayout::FieldRole, emailmod);

        label_20 = new QLabel(modifyTab);
        label_20->setObjectName("label_20");

        modifyFormLayout->setWidget(5, QFormLayout::LabelRole, label_20);

        label_22 = new QLabel(modifyTab);
        label_22->setObjectName("label_22");

        modifyFormLayout->setWidget(6, QFormLayout::LabelRole, label_22);


        modifyLayout->addLayout(modifyFormLayout);

        modifyButtonLayout = new QHBoxLayout();
        modifyButtonLayout->setSpacing(15);
        modifyButtonLayout->setObjectName("modifyButtonLayout");
        modifyButtonSpacer = new QSpacerItem(40, 20, QSizePolicy::Policy::Expanding, QSizePolicy::Policy::Minimum);

        modifyButtonLayout->addItem(modifyButtonSpacer);

        addContratBtn = new QPushButton(modifyTab);
        addContratBtn->setObjectName("addContratBtn");
        addContratBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        modifyButtonLayout->addWidget(addContratBtn);

        updateContratBtn = new QPushButton(modifyTab);
        updateContratBtn->setObjectName("updateContratBtn");
        updateContratBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        modifyButtonLayout->addWidget(updateContratBtn);

        deleteContratBtn = new QPushButton(modifyTab);
        deleteContratBtn->setObjectName("deleteContratBtn");
        deleteContratBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        modifyButtonLayout->addWidget(deleteContratBtn);


        modifyLayout->addLayout(modifyButtonLayout);

        modifyVerticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Policy::Minimum, QSizePolicy::Policy::Expanding);

        modifyLayout->addItem(modifyVerticalSpacer);

        contratsTabWidget->addTab(modifyTab, QString());
        notificationTab = new QWidget();
        notificationTab->setObjectName("notificationTab");
        notificationLayout = new QVBoxLayout(notificationTab);
        notificationLayout->setSpacing(15);
        notificationLayout->setObjectName("notificationLayout");
        notificationLayout->setContentsMargins(20, 20, 20, 20);
        notificationControlLayout = new QHBoxLayout();
        notificationControlLayout->setObjectName("notificationControlLayout");
        notification = new QPushButton(notificationTab);
        notification->setObjectName("notification");
        notification->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        notificationControlLayout->addWidget(notification);


        notificationLayout->addLayout(notificationControlLayout);

        contratsTabWidget->addTab(notificationTab, QString());
        chatbotTab = new QWidget();
        chatbotTab->setObjectName("chatbotTab");
        chatbotLayout = new QVBoxLayout(chatbotTab);
        chatbotLayout->setSpacing(15);
        chatbotLayout->setObjectName("chatbotLayout");
        chatbotLayout->setContentsMargins(20, 20, 20, 20);
        voicechat = new QPushButton(chatbotTab);
        voicechat->setObjectName("voicechat");
        voicechat->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"color: white;\n"
"border-radius: 12px;\n"
"padding: 8px 16px;"));

        chatbotLayout->addWidget(voicechat);

        contratsTabWidget->addTab(chatbotTab, QString());
        stack->addWidget(page_5);
        page_circuit = new QWidget();
        page_circuit->setObjectName("page_circuit");
        tabWidget_circuit = new QTabWidget(page_circuit);
        tabWidget_circuit->setObjectName("tabWidget_circuit");
        tabWidget_circuit->setGeometry(QRect(10, 20, 1241, 811));
        tabWidget_circuit->setStyleSheet(QString::fromUtf8("font: 12pt \"Segoe UI\";"));
        tabCircuitAccueil = new QWidget();
        tabCircuitAccueil->setObjectName("tabCircuitAccueil");
        labelTitreCircuit = new QLabel(tabCircuitAccueil);
        labelTitreCircuit->setObjectName("labelTitreCircuit");
        labelTitreCircuit->setGeometry(QRect(490, -10, 471, 61));
        labelTitreCircuit->setFont(font3);
        labelTitreCircuit->setStyleSheet(QString::fromUtf8("font: 16pt \"Segoe UI\";"));
        pushButton_export_circuit = new QPushButton(tabCircuitAccueil);
        pushButton_export_circuit->setObjectName("pushButton_export_circuit");
        pushButton_export_circuit->setGeometry(QRect(430, 660, 151, 41));
        pushButton_export_circuit->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;\n"
"    border-radius: 12px;\n"
"    padding: 8px 16px;"));
        label_export_circuit = new QLabel(tabCircuitAccueil);
        label_export_circuit->setObjectName("label_export_circuit");
        label_export_circuit->setGeometry(QRect(590, 670, 63, 31));
        label_export_circuit->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        groupBoxCircuit = new QGroupBox(tabCircuitAccueil);
        groupBoxCircuit->setObjectName("groupBoxCircuit");
        groupBoxCircuit->setGeometry(QRect(0, 0, 351, 851));
        groupBoxCircuit->setStyleSheet(QString::fromUtf8("QGroupBox {\n"
"        font: 900 9pt \"Segoe UI\";\n"
"        font: 900 9pt \"Segoe UI\";\n"
"        font: 16pt \"Segoe UI\";\n"
"\n"
"        background-color: rgb(135, 206, 235);\n"
"    border: 2px solid #4682B4;\n"
"    border-radius: 8px;\n"
"    margin-top: 10px;\n"
"}\n"
"QPushButton {\n"
"    background-color: #4682B4;\n"
"    color: white;\n"
"    border-radius: 5px;\n"
"    padding: 5px;\n"
"}\n"
"QPushButton:hover {\n"
"    background-color: #5A9BD5;\n"
"}"));
        labelIdCircuit = new QLabel(groupBoxCircuit);
        labelIdCircuit->setObjectName("labelIdCircuit");
        labelIdCircuit->setGeometry(QRect(20, 30, 201, 21));
        labelIdCircuit->setFont(font4);
        lineEdit_id_circuit = new QLineEdit(groupBoxCircuit);
        lineEdit_id_circuit->setObjectName("lineEdit_id_circuit");
        lineEdit_id_circuit->setGeometry(QRect(40, 60, 171, 31));
        labelNomCircuit = new QLabel(groupBoxCircuit);
        labelNomCircuit->setObjectName("labelNomCircuit");
        labelNomCircuit->setGeometry(QRect(20, 110, 171, 21));
        labelNomCircuit->setFont(font4);
        lineEdit_nom_circuit = new QLineEdit(groupBoxCircuit);
        lineEdit_nom_circuit->setObjectName("lineEdit_nom_circuit");
        lineEdit_nom_circuit->setGeometry(QRect(40, 140, 171, 31));
        labelDescCircuit = new QLabel(groupBoxCircuit);
        labelDescCircuit->setObjectName("labelDescCircuit");
        labelDescCircuit->setGeometry(QRect(20, 190, 171, 21));
        labelDescCircuit->setFont(font4);
        textEdit_desc_circuit = new QTextEdit(groupBoxCircuit);
        textEdit_desc_circuit->setObjectName("textEdit_desc_circuit");
        textEdit_desc_circuit->setGeometry(QRect(40, 220, 171, 61));
        labelDistance = new QLabel(groupBoxCircuit);
        labelDistance->setObjectName("labelDistance");
        labelDistance->setGeometry(QRect(20, 300, 171, 21));
        labelDistance->setFont(font4);
        lineEdit_distance = new QLineEdit(groupBoxCircuit);
        lineEdit_distance->setObjectName("lineEdit_distance");
        lineEdit_distance->setGeometry(QRect(40, 330, 171, 31));
        labelDuree = new QLabel(groupBoxCircuit);
        labelDuree->setObjectName("labelDuree");
        labelDuree->setGeometry(QRect(20, 390, 171, 21));
        labelDuree->setFont(font4);
        lineEdit_duree_circuit = new QLineEdit(groupBoxCircuit);
        lineEdit_duree_circuit->setObjectName("lineEdit_duree_circuit");
        lineEdit_duree_circuit->setGeometry(QRect(30, 440, 171, 31));
        labelDifficulte = new QLabel(groupBoxCircuit);
        labelDifficulte->setObjectName("labelDifficulte");
        labelDifficulte->setGeometry(QRect(20, 490, 171, 21));
        labelDifficulte->setFont(font4);
        comboBox_difficulte = new QComboBox(groupBoxCircuit);
        comboBox_difficulte->addItem(QString());
        comboBox_difficulte->addItem(QString());
        comboBox_difficulte->addItem(QString());
        comboBox_difficulte->setObjectName("comboBox_difficulte");
        comboBox_difficulte->setGeometry(QRect(30, 540, 171, 31));
        labelImmatCircuit = new QLabel(groupBoxCircuit);
        labelImmatCircuit->setObjectName("labelImmatCircuit");
        labelImmatCircuit->setGeometry(QRect(20, 590, 221, 31));
        labelImmatCircuit->setFont(font4);
        lineEdit_immat_circuit = new QLineEdit(groupBoxCircuit);
        lineEdit_immat_circuit->setObjectName("lineEdit_immat_circuit");
        lineEdit_immat_circuit->setGeometry(QRect(40, 650, 171, 31));
        pushButton_validercircuit = new QPushButton(groupBoxCircuit);
        pushButton_validercircuit->setObjectName("pushButton_validercircuit");
        pushButton_validercircuit->setGeometry(QRect(10, 720, 121, 41));
        pushButton_validercircuit->setFont(font4);
        pushButton_modifiercircuit = new QPushButton(groupBoxCircuit);
        pushButton_modifiercircuit->setObjectName("pushButton_modifiercircuit");
        pushButton_modifiercircuit->setGeometry(QRect(190, 710, 111, 41));
        pushButton_modifiercircuit->setFont(font4);
        pushButton_supprimercircuit = new QPushButton(groupBoxCircuit);
        pushButton_supprimercircuit->setObjectName("pushButton_supprimercircuit");
        pushButton_supprimercircuit->setGeometry(QRect(10, 790, 311, 41));
        pushButton_supprimercircuit->setStyleSheet(QString::fromUtf8("background-color: rgb(220, 20, 60);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;\n"
"    border-radius: 12px;\n"
"    padding: 8px 16px;"));
        tableView_circuits = new QTableView(tabCircuitAccueil);
        tableView_circuits->setObjectName("tableView_circuits");
        tableView_circuits->setGeometry(QRect(350, 90, 751, 371));
        tableView_circuits->setStyleSheet(QString::fromUtf8("background-color: #00008B;\n"
"    color: white;\n"
"    gridline-color: white;\n"
"    border-radius: 8px;\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: #34495e;\n"
"    color: white;\n"
"    padding: 4px;\n"
"    border: 1px solid #2c3e50;"));
        pushButton_supprimercircuit_bas = new QPushButton(tabCircuitAccueil);
        pushButton_supprimercircuit_bas->setObjectName("pushButton_supprimercircuit_bas");
        pushButton_supprimercircuit_bas->setGeometry(QRect(870, 510, 171, 41));
        pushButton_supprimercircuit_bas->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;\n"
"    border-radius: 12px;\n"
"    padding: 8px 16px;"));
        tabWidget_circuit->addTab(tabCircuitAccueil, QString());
        tableView_circuits->raise();
        labelTitreCircuit->raise();
        groupBoxCircuit->raise();
        pushButton_export_circuit->raise();
        label_export_circuit->raise();
        pushButton_supprimercircuit_bas->raise();
        tabCircuitRecherche = new QWidget();
        tabCircuitRecherche->setObjectName("tabCircuitRecherche");
        label_recherche_circuit = new QLabel(tabCircuitRecherche);
        label_recherche_circuit->setObjectName("label_recherche_circuit");
        label_recherche_circuit->setGeometry(QRect(50, 50, 251, 31));
        label_recherche_circuit->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        lineEdit_recherche_circuit = new QLineEdit(tabCircuitRecherche);
        lineEdit_recherche_circuit->setObjectName("lineEdit_recherche_circuit");
        lineEdit_recherche_circuit->setGeometry(QRect(290, 50, 241, 41));
        pushButton_recherchecircuit = new QPushButton(tabCircuitRecherche);
        pushButton_recherchecircuit->setObjectName("pushButton_recherchecircuit");
        pushButton_recherchecircuit->setGeometry(QRect(550, 50, 141, 41));
        pushButton_recherchecircuit->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;\n"
"    border-radius: 12px;\n"
"    padding: 8px 16px;"));
        label_trier_circuit = new QLabel(tabCircuitRecherche);
        label_trier_circuit->setObjectName("label_trier_circuit");
        label_trier_circuit->setGeometry(QRect(50, 150, 151, 31));
        label_trier_circuit->setStyleSheet(QString::fromUtf8("font: 14pt \"Segoe UI\";"));
        comboBox_trier_circuit = new QComboBox(tabCircuitRecherche);
        comboBox_trier_circuit->addItem(QString());
        comboBox_trier_circuit->addItem(QString());
        comboBox_trier_circuit->addItem(QString());
        comboBox_trier_circuit->setObjectName("comboBox_trier_circuit");
        comboBox_trier_circuit->setGeometry(QRect(220, 150, 201, 41));
        comboBox_trier_circuit->setStyleSheet(QString::fromUtf8("background-color: rgb(70, 130, 180);\n"
"font: 14pt \"Segoe UI\";\n"
"font: 900 12pt \"Segoe UI\";\n"
"\n"
"    color: white;\n"
"    padding: 8px 16px;"));
        tableView_circuits_recherche = new QTableView(tabCircuitRecherche);
        tableView_circuits_recherche->setObjectName("tableView_circuits_recherche");
        tableView_circuits_recherche->setGeometry(QRect(50, 250, 1101, 501));
        tableView_circuits_recherche->setStyleSheet(QString::fromUtf8("background-color: #00008B;\n"
"    color: white;\n"
"    gridline-color: white;\n"
"    border-radius: 8px;\n"
"}\n"
"QHeaderView::section {\n"
"    background-color: #34495e;\n"
"    color: white;\n"
"    padding: 4px;\n"
"    border: 1px solid #2c3e50;"));
        tabWidget_circuit->addTab(tabCircuitRecherche, QString());
        stack->addWidget(page_circuit);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 1564, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName("statusbar");
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        stack->setCurrentIndex(5);
        tabWidget->setCurrentIndex(0);
        tabWidget_2->setCurrentIndex(0);
        tabWidget_3->setCurrentIndex(1);
        tabWidget_4->setCurrentIndex(0);
        contratsTabWidget->setCurrentIndex(0);
        tabWidget_circuit->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        seance->setText(QCoreApplication::translate("MainWindow", "\360\237\223\205 S\303\251ance", nullptr));
        employe->setText(QCoreApplication::translate("MainWindow", "\360\237\221\250\342\200\215\360\237\222\274 Employ\303\251", nullptr));
        client->setText(QCoreApplication::translate("MainWindow", "\360\237\221\244 Client", nullptr));
        vehicule->setText(QCoreApplication::translate("MainWindow", " \360\237\232\227 v\303\251hicule", nullptr));
        moniteur->setText(QCoreApplication::translate("MainWindow", "\342\234\215\357\270\217 Moniteur", nullptr));
        cercuit->setText(QCoreApplication::translate("MainWindow", "\360\237\224\204 Cercuit", nullptr));
        employe_2->setText(QCoreApplication::translate("MainWindow", "\360\237\217\240 Acceuil", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "Rechrcher une seance :", nullptr));
        comboBox_trier->setItemText(0, QCoreApplication::translate("MainWindow", "Par ID", nullptr));
        comboBox_trier->setItemText(1, QCoreApplication::translate("MainWindow", "Par Date", nullptr));

#if QT_CONFIG(whatsthis)
        lineEdit_recherche->setWhatsThis(QCoreApplication::translate("MainWindow", "<html><head/><body><p>hhhh</p><p><br/></p></body></html>", nullptr));
#endif // QT_CONFIG(whatsthis)
        label_3->setText(QCoreApplication::translate("MainWindow", "\360\237\224\215", nullptr));
        pushButton_supprimer->setText(QCoreApplication::translate("MainWindow", "Supprimer\360\237\227\221\357\270\217", nullptr));
        groupBox->setTitle(QCoreApplication::translate("MainWindow", "\342\236\225 Ajouter une seance", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\360\237\224\221Id_seance", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\360\237\223\205Date", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "\360\237\225\222Heure de d\303\251but", nullptr));
        label_9->setText(QCoreApplication::translate("MainWindow", "\342\217\263Dur\303\251e", nullptr));
        label_10->setText(QCoreApplication::translate("MainWindow", "\360\237\232\227Type", nullptr));
        comboBox_type->setItemText(0, QString());
        comboBox_type->setItemText(1, QCoreApplication::translate("MainWindow", "CODE", nullptr));
        comboBox_type->setItemText(2, QCoreApplication::translate("MainWindow", "COND", nullptr));
        comboBox_type->setItemText(3, QCoreApplication::translate("MainWindow", "PARC", nullptr));

        pushButton_valider->setText(QCoreApplication::translate("MainWindow", "Valider", nullptr));
        pushButton_modifier->setText(QCoreApplication::translate("MainWindow", "modifier", nullptr));
        label_14->setText(QCoreApplication::translate("MainWindow", "\360\237\226\245\357\270\217\360\237\232\227 appareil ", nullptr));
        label_15->setText(QCoreApplication::translate("MainWindow", "id_client :", nullptr));
        label_16->setText(QCoreApplication::translate("MainWindow", "immatricule :", nullptr));
        label_17->setText(QCoreApplication::translate("MainWindow", "id_moniteur :", nullptr));
        pushButton_recherche->setText(QCoreApplication::translate("MainWindow", "recherche", nullptr));
        label_12->setText(QCoreApplication::translate("MainWindow", "Trier par :", nullptr));
        pushButton_export->setText(QCoreApplication::translate("MainWindow", "Exporation", nullptr));
        label_13->setText(QCoreApplication::translate("MainWindow", "\342\254\207\357\270\217", nullptr));
        label_19->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:700;\">Gestion des s\303\251ances</span></p></body></html>", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "Acceuil", nullptr));
        label_18->setText(QString());
        label_21->setText(QString());
        label_11->setText(QCoreApplication::translate("MainWindow", "Statistiques selon les Types", nullptr));
        pushButton_statistiques->setText(QCoreApplication::translate("MainWindow", "Statistique", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        label_25->setText(QString());
        label_6->setText(QCoreApplication::translate("MainWindow", "Affectuer une date :", nullptr));
        label_23->setText(QCoreApplication::translate("MainWindow", "Rappel d'une seances par Mail", nullptr));
        pushButton_envoyer->setText(QCoreApplication::translate("MainWindow", "Envoyer", nullptr));
        label_24->setText(QCoreApplication::translate("MainWindow", "\360\237\223\247", nullptr));
        calendrier->setText(QCoreApplication::translate("MainWindow", "calendrier", nullptr));
        pushButton_mois_precedent->setText(QCoreApplication::translate("MainWindow", "MoisPrecedent", nullptr));
        pushButton_mois_suivant->setText(QCoreApplication::translate("MainWindow", "MoisSuivant", nullptr));
        pushButton_rafraichir_calendrier->setText(QCoreApplication::translate("MainWindow", "AfficherCalendrier", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "Autres M\303\251tiers", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("MainWindow", "\342\236\225Ajouter employ\303\251:", nullptr));
        label_87->setText(QCoreApplication::translate("MainWindow", "\360\237\221\250\342\200\215\360\237\222\273ID Employ\303\251:", nullptr));
        label_88->setText(QCoreApplication::translate("MainWindow", "\360\237\224\240Nom:", nullptr));
        label_89->setText(QCoreApplication::translate("MainWindow", "\360\237\224\240Pr\303\251nom:", nullptr));
        label_90->setText(QCoreApplication::translate("MainWindow", "\360\237\222\274Poste:", nullptr));
        label_91->setText(QCoreApplication::translate("MainWindow", "\360\237\224\243Mot de passe:", nullptr));
        label_92->setText(QCoreApplication::translate("MainWindow", "\360\237\223\236Num t\303\251l\303\251phonique:", nullptr));
        label_93->setText(QCoreApplication::translate("MainWindow", "\360\237\223\206Date d'embauche:", nullptr));
        pushButton_26->setText(QCoreApplication::translate("MainWindow", "Ajouter", nullptr));
        label_94->setText(QCoreApplication::translate("MainWindow", "+216", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_5->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_5->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_5->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("MainWindow", "Prenom", nullptr));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget_5->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QCoreApplication::translate("MainWindow", "Poste", nullptr));
        QTableWidgetItem *___qtablewidgetitem4 = tableWidget_5->horizontalHeaderItem(4);
        ___qtablewidgetitem4->setText(QCoreApplication::translate("MainWindow", "Mot de passe", nullptr));
        QTableWidgetItem *___qtablewidgetitem5 = tableWidget_5->horizontalHeaderItem(5);
        ___qtablewidgetitem5->setText(QCoreApplication::translate("MainWindow", "Num t\303\251l\303\251phonique:", nullptr));
        QTableWidgetItem *___qtablewidgetitem6 = tableWidget_5->horizontalHeaderItem(6);
        ___qtablewidgetitem6->setText(QCoreApplication::translate("MainWindow", "Date d'embauche:", nullptr));
        label_95->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:26pt; font-weight:700; color:#00008b;\">Gestion employ\303\251s</span></p></body></html>", nullptr));
        pushButton_27->setText(QCoreApplication::translate("MainWindow", "Afficher \360\237\224\215", nullptr));
        lineEdit_30->setText(QString());
        label_96->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Ajouter Employ\303\251:</span></p></body></html>", nullptr));
        pushButton_28->setText(QCoreApplication::translate("MainWindow", "Supprimer \360\237\227\221", nullptr));
        label_97->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Supprimer employ\303\251:</span></p></body></html>", nullptr));
        label_98->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Trier par:</span></p></body></html>", nullptr));
        comboBox_8->setItemText(0, QCoreApplication::translate("MainWindow", "Poste ", nullptr));
        comboBox_8->setItemText(1, QCoreApplication::translate("MainWindow", "ID", nullptr));
        comboBox_8->setItemText(2, QString());

        pushButton_29->setText(QCoreApplication::translate("MainWindow", "Exporter\360\237\223\221", nullptr));
        checkBox_27->setText(QCoreApplication::translate("MainWindow", "\360\237\226\214", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_12), QCoreApplication::translate("MainWindow", "Ajouter", nullptr));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_13), QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        labelTitre->setText(QCoreApplication::translate("MainWindow", "Ajouter clients:", nullptr));
        labelNom->setText(QCoreApplication::translate("MainWindow", "Nom:", nullptr));
        labelPrenom->setText(QCoreApplication::translate("MainWindow", "Pr\303\251nom:", nullptr));
        labelCIN->setText(QCoreApplication::translate("MainWindow", "CIN:", nullptr));
        labelPoste->setText(QCoreApplication::translate("MainWindow", "Date de naissance:", nullptr));
        jjj->setDisplayFormat(QCoreApplication::translate("MainWindow", "dd/MM/yyyy", nullptr));
        labelMotDePasse->setText(QCoreApplication::translate("MainWindow", "Adresse:", nullptr));
        labelTelephone->setText(QCoreApplication::translate("MainWindow", "Num t\303\251l\303\251phonique:", nullptr));
        labelIndicatif->setText(QCoreApplication::translate("MainWindow", "+216", nullptr));
        labelDateEmbauche->setText(QCoreApplication::translate("MainWindow", "Email:", nullptr));
        labelLatitude->setText(QCoreApplication::translate("MainWindow", "Latitude:", nullptr));
        labelLongitude->setText(QCoreApplication::translate("MainWindow", "Longitude:", nullptr));
        btnAjouter->setText(QCoreApplication::translate("MainWindow", "Ajouter", nullptr));
        btnModifier->setText(QCoreApplication::translate("MainWindow", "Modifier", nullptr));
        labelGestion->setText(QCoreApplication::translate("MainWindow", "Gestion clients", nullptr));
        labelAfficher->setText(QCoreApplication::translate("MainWindow", "Afficher client:", nullptr));
        btnChercher->setText(QCoreApplication::translate("MainWindow", "Chercher", nullptr));
        btnClear->setText(QCoreApplication::translate("MainWindow", "Clear", nullptr));
        labelTrier->setText(QCoreApplication::translate("MainWindow", "Trier par:", nullptr));
        comboBoxTrier->setItemText(0, QCoreApplication::translate("MainWindow", "ID", nullptr));
        comboBoxTrier->setItemText(1, QCoreApplication::translate("MainWindow", "Nom", nullptr));

        QTableWidgetItem *___qtablewidgetitem7 = tableWidget_6->horizontalHeaderItem(0);
        ___qtablewidgetitem7->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem8 = tableWidget_6->horizontalHeaderItem(1);
        ___qtablewidgetitem8->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem9 = tableWidget_6->horizontalHeaderItem(2);
        ___qtablewidgetitem9->setText(QCoreApplication::translate("MainWindow", "Prenom", nullptr));
        QTableWidgetItem *___qtablewidgetitem10 = tableWidget_6->horizontalHeaderItem(3);
        ___qtablewidgetitem10->setText(QCoreApplication::translate("MainWindow", "Date de naissence", nullptr));
        QTableWidgetItem *___qtablewidgetitem11 = tableWidget_6->horizontalHeaderItem(4);
        ___qtablewidgetitem11->setText(QCoreApplication::translate("MainWindow", "Adresse", nullptr));
        QTableWidgetItem *___qtablewidgetitem12 = tableWidget_6->horizontalHeaderItem(5);
        ___qtablewidgetitem12->setText(QCoreApplication::translate("MainWindow", "Num", nullptr));
        QTableWidgetItem *___qtablewidgetitem13 = tableWidget_6->horizontalHeaderItem(6);
        ___qtablewidgetitem13->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        labelSupprimer->setText(QCoreApplication::translate("MainWindow", "Supprimer client:", nullptr));
        btnGenererQRClient->setText(QCoreApplication::translate("MainWindow", "\360\237\223\261 G\303\251n\303\251rer QR", nullptr));
        btnExporterPDF->setText(QCoreApplication::translate("MainWindow", "\360\237\223\204 Exporter PDF", nullptr));
        btnSupprimer->setText(QCoreApplication::translate("MainWindow", "Supprimer", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_crud), QCoreApplication::translate("MainWindow", "Insertion Client", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_ajouter), QCoreApplication::translate("MainWindow", "Statistique", nullptr));
        label_102->setText(QString());
        label_103->setText(QCoreApplication::translate("MainWindow", "JPS Maps", nullptr));
        labelClientMapSearch->setText(QCoreApplication::translate("MainWindow", "ID ou Nom du client :", nullptr));
        btnShowClientOnMap->setText(QCoreApplication::translate("MainWindow", "\360\237\223\215 Voir position du client", nullptr));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_14), QCoreApplication::translate("MainWindow", "M\303\251tiers", nullptr));
        labelTitre_2->setText(QCoreApplication::translate("MainWindow", "Gestion des V\303\251hicules", nullptr));
        groupBoxAjout->setTitle(QCoreApplication::translate("MainWindow", "\342\236\225 Ajouter un v\303\251hicule", nullptr));
        labelImmatricule->setText(QCoreApplication::translate("MainWindow", "\360\237\224\242 Immatricule :", nullptr));
        labelModele->setText(QCoreApplication::translate("MainWindow", "\360\237\232\227 Mod\303\250le :", nullptr));
        labelType->setText(QCoreApplication::translate("MainWindow", "\360\237\232\233 Type :", nullptr));
        comboBox_type_2->setItemText(0, QCoreApplication::translate("MainWindow", "\360\237\232\227 Voiture", nullptr));
        comboBox_type_2->setItemText(1, QCoreApplication::translate("MainWindow", "\360\237\232\233 Camion", nullptr));
        comboBox_type_2->setItemText(2, QCoreApplication::translate("MainWindow", "\360\237\217\215\357\270\217 Moto", nullptr));

        pushButton_validervehicule->setText(QCoreApplication::translate("MainWindow", "Valider", nullptr));
        pushButton_modifiervehicule->setText(QCoreApplication::translate("MainWindow", "Modifier", nullptr));
        label_104->setText(QCoreApplication::translate("MainWindow", "\360\237\223\235Date d'assurance:", nullptr));
        comboBox_etat->setItemText(0, QCoreApplication::translate("MainWindow", "\360\237\237\242Disponible", nullptr));
        comboBox_etat->setItemText(1, QCoreApplication::translate("MainWindow", "\360\237\224\264Indisponible", nullptr));

        label_105->setText(QCoreApplication::translate("MainWindow", "\342\234\205Etat :", nullptr));
        comboBox_transmission->setItemText(0, QCoreApplication::translate("MainWindow", "\360\237\205\260\357\270\217 Automatique", nullptr));
        comboBox_transmission->setItemText(1, QCoreApplication::translate("MainWindow", "\360\237\205\274 Manuelle", nullptr));

        label_106->setText(QCoreApplication::translate("MainWindow", "\342\232\231\357\270\217 Transmission :", nullptr));
        lineEdit_rechercheVehicule->setPlaceholderText(QCoreApplication::translate("MainWindow", "\360\237\224\215 Rechercher un v\303\251hicule...", nullptr));
        pushButton_exporterVehicule->setText(QCoreApplication::translate("MainWindow", "Exportation \360\237\223\244", nullptr));
        pushButton_rechercheVehicule->setText(QCoreApplication::translate("MainWindow", "Valider", nullptr));
        label_107->setText(QCoreApplication::translate("MainWindow", "\342\206\225\357\270\217Trier par :", nullptr));
        comboBox_trierVehicule->setItemText(0, QCoreApplication::translate("MainWindow", "Immatricule", nullptr));
        comboBox_trierVehicule->setItemText(1, QCoreApplication::translate("MainWindow", "Modele", nullptr));
        comboBox_trierVehicule->setItemText(2, QCoreApplication::translate("MainWindow", "Type", nullptr));

        pushButton_supprimervehicule->setText(QCoreApplication::translate("MainWindow", "Supprimer \360\237\227\221\357\270\217", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tabAcceuil), QCoreApplication::translate("MainWindow", "Acceuil", nullptr));
        label_109->setText(QString());
        label_110->setText(QString());
        pushButton_statistiques_2->setText(QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        label_27->setText(QCoreApplication::translate("MainWindow", "Statistiques de vehicules:", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tabStats), QCoreApplication::translate("MainWindow", "Statistiques", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("MainWindow", "\360\237\224\224Notification d'assurance", nullptr));
        QTableWidgetItem *___qtablewidgetitem14 = tableWidget_assurance->horizontalHeaderItem(0);
        ___qtablewidgetitem14->setText(QCoreApplication::translate("MainWindow", "Immatricule", nullptr));
        QTableWidgetItem *___qtablewidgetitem15 = tableWidget_assurance->horizontalHeaderItem(1);
        ___qtablewidgetitem15->setText(QCoreApplication::translate("MainWindow", "date_assurance", nullptr));
        QTableWidgetItem *___qtablewidgetitem16 = tableWidget_assurance->horizontalHeaderItem(2);
        ___qtablewidgetitem16->setText(QCoreApplication::translate("MainWindow", "Statut", nullptr));
        label_expired->setText(QCoreApplication::translate("MainWindow", "expired", nullptr));
        label_soon->setText(QCoreApplication::translate("MainWindow", "soon", nullptr));
        groupBox_7->setTitle(QCoreApplication::translate("MainWindow", "\360\237\223\226Historique des vehicules:", nullptr));
        pushButton_historique->setText(QCoreApplication::translate("MainWindow", "Historique", nullptr));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_15), QCoreApplication::translate("MainWindow", "Metiers", nullptr));
        searchEdit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Rechercher...", nullptr));
        stat->setText(QCoreApplication::translate("MainWindow", "Statistique", nullptr));
        searchBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\224\215 Chercher", nullptr));
        sortBtn->setText(QCoreApplication::translate("MainWindow", "\342\206\225\357\270\217 Trier", nullptr));
        exportPdfBtnMoniteur->setText(QCoreApplication::translate("MainWindow", "\360\237\223\204 Exporter", nullptr));
        QTableWidgetItem *___qtablewidgetitem17 = moniteurTable->horizontalHeaderItem(0);
        ___qtablewidgetitem17->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        QTableWidgetItem *___qtablewidgetitem18 = moniteurTable->horizontalHeaderItem(1);
        ___qtablewidgetitem18->setText(QCoreApplication::translate("MainWindow", "CIN", nullptr));
        QTableWidgetItem *___qtablewidgetitem19 = moniteurTable->horizontalHeaderItem(2);
        ___qtablewidgetitem19->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        QTableWidgetItem *___qtablewidgetitem20 = moniteurTable->horizontalHeaderItem(3);
        ___qtablewidgetitem20->setText(QCoreApplication::translate("MainWindow", "Prenom", nullptr));
        QTableWidgetItem *___qtablewidgetitem21 = moniteurTable->horizontalHeaderItem(4);
        ___qtablewidgetitem21->setText(QCoreApplication::translate("MainWindow", "Tel", nullptr));
        QTableWidgetItem *___qtablewidgetitem22 = moniteurTable->horizontalHeaderItem(5);
        ___qtablewidgetitem22->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        QTableWidgetItem *___qtablewidgetitem23 = moniteurTable->horizontalHeaderItem(6);
        ___qtablewidgetitem23->setText(QCoreApplication::translate("MainWindow", "Permis", nullptr));
        Modifiermoniteur->setText(QCoreApplication::translate("MainWindow", "Modifier", nullptr));
        supprimermoniteur->setText(QCoreApplication::translate("MainWindow", "Supprimer", nullptr));
        contratsTabWidget->setTabText(contratsTabWidget->indexOf(displayTab), QCoreApplication::translate("MainWindow", "\360\237\224\216 Afficher", nullptr));
        modifyIdLabel->setText(QCoreApplication::translate("MainWindow", "ID", nullptr));
        modifyNameLabel->setText(QCoreApplication::translate("MainWindow", "CIN", nullptr));
        modifyEmailLabel->setText(QCoreApplication::translate("MainWindow", "Nom", nullptr));
        modifyPhoneLabel->setText(QCoreApplication::translate("MainWindow", "Prenom", nullptr));
        modifyCompanyLabel->setText(QCoreApplication::translate("MainWindow", "Tel", nullptr));
        label_20->setText(QCoreApplication::translate("MainWindow", "Email", nullptr));
        label_22->setText(QCoreApplication::translate("MainWindow", "Permis", nullptr));
        addContratBtn->setText(QCoreApplication::translate("MainWindow", "\342\236\225 Ajouter", nullptr));
        updateContratBtn->setText(QCoreApplication::translate("MainWindow", "\342\234\217\357\270\217 Modifier", nullptr));
        deleteContratBtn->setText(QCoreApplication::translate("MainWindow", "\360\237\227\221\357\270\217", nullptr));
        contratsTabWidget->setTabText(contratsTabWidget->indexOf(modifyTab), QCoreApplication::translate("MainWindow", "\342\234\205 Ajout", nullptr));
        notification->setText(QCoreApplication::translate("MainWindow", "\360\237\224\224 Notification", nullptr));
        contratsTabWidget->setTabText(contratsTabWidget->indexOf(notificationTab), QCoreApplication::translate("MainWindow", "\360\237\224\224 Notification", nullptr));
        voicechat->setText(QCoreApplication::translate("MainWindow", "VOICE CHAT", nullptr));
        contratsTabWidget->setTabText(contratsTabWidget->indexOf(chatbotTab), QCoreApplication::translate("MainWindow", "\360\237\222\254 VoiceChat", nullptr));
        labelTitreCircuit->setText(QCoreApplication::translate("MainWindow", "Gestion des Circuits", nullptr));
        pushButton_export_circuit->setText(QCoreApplication::translate("MainWindow", "Exporation", nullptr));
        label_export_circuit->setText(QCoreApplication::translate("MainWindow", "\342\254\207\357\270\217", nullptr));
        groupBoxCircuit->setTitle(QCoreApplication::translate("MainWindow", "\342\236\225 Ajouter un circuit", nullptr));
        labelIdCircuit->setText(QCoreApplication::translate("MainWindow", "\360\237\224\242 ID Circuit :", nullptr));
        labelNomCircuit->setText(QCoreApplication::translate("MainWindow", "\360\237\223\235 Nom Circuit :", nullptr));
        labelDescCircuit->setText(QCoreApplication::translate("MainWindow", "\360\237\223\204 Description :", nullptr));
        labelDistance->setText(QCoreApplication::translate("MainWindow", "\360\237\223\217 Distance (km) :", nullptr));
        labelDuree->setText(QCoreApplication::translate("MainWindow", "\342\217\261\357\270\217 Dur\303\251e (min) :", nullptr));
        labelDifficulte->setText(QCoreApplication::translate("MainWindow", "\342\232\241 Difficult\303\251 :", nullptr));
        comboBox_difficulte->setItemText(0, QCoreApplication::translate("MainWindow", "\360\237\237\242 Facile", nullptr));
        comboBox_difficulte->setItemText(1, QCoreApplication::translate("MainWindow", "\360\237\237\241 Moyen", nullptr));
        comboBox_difficulte->setItemText(2, QCoreApplication::translate("MainWindow", "\360\237\224\264 Difficile", nullptr));

        labelImmatCircuit->setText(QCoreApplication::translate("MainWindow", "\360\237\232\227 Immatricule :", nullptr));
        pushButton_validercircuit->setText(QCoreApplication::translate("MainWindow", "\342\234\205 Valider", nullptr));
        pushButton_modifiercircuit->setText(QCoreApplication::translate("MainWindow", "\342\234\217\357\270\217 Modifier", nullptr));
        pushButton_supprimercircuit->setText(QCoreApplication::translate("MainWindow", "\360\237\227\221\357\270\217 Supprimer", nullptr));
        pushButton_supprimercircuit_bas->setText(QCoreApplication::translate("MainWindow", "Supprimer \360\237\227\221\357\270\217", nullptr));
        tabWidget_circuit->setTabText(tabWidget_circuit->indexOf(tabCircuitAccueil), QCoreApplication::translate("MainWindow", "Accueil", nullptr));
        label_recherche_circuit->setText(QCoreApplication::translate("MainWindow", "\360\237\224\215 Rechercher un circuit :", nullptr));
        lineEdit_recherche_circuit->setPlaceholderText(QCoreApplication::translate("MainWindow", "Rechercher par ID, Nom, Description, Distance, Dur\303\251e, Difficult\303\251 ou Immatricule...", nullptr));
        pushButton_recherchecircuit->setText(QCoreApplication::translate("MainWindow", "\360\237\224\215 Rechercher", nullptr));
        label_trier_circuit->setText(QCoreApplication::translate("MainWindow", "\342\206\225\357\270\217 Trier par :", nullptr));
        comboBox_trier_circuit->setItemText(0, QCoreApplication::translate("MainWindow", "ID Circuit", nullptr));
        comboBox_trier_circuit->setItemText(1, QCoreApplication::translate("MainWindow", "Nom", nullptr));
        comboBox_trier_circuit->setItemText(2, QCoreApplication::translate("MainWindow", "Distance", nullptr));

        tabWidget_circuit->setTabText(tabWidget_circuit->indexOf(tabCircuitRecherche), QCoreApplication::translate("MainWindow", "\360\237\224\216 Recherche et Tri", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
