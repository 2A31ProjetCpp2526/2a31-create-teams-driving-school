#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "seance.h"
#include "vehicule.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void seanceclick();
    void employeclick();
    void clientclick();
    void vehiculeclick();
    void contratclick();

    // Slots pour les opérations CRUD des séances
    void on_pushButton_valider_clicked();
    void on_pushButton_modifier_clicked();
    void on_pushButton_supprimer_clicked();
    void on_pushButton_recherche_clicked();
    void on_tableView_seances_clicked(const QModelIndex &index);

    // Slots pour les opérations CRUD des véhicules
    void on_pushButton_validervehicule_clicked();
    void on_pushButton_supprimervehicule_clicked();
    void on_pushButton_modifiervehicule_clicked();
    void on_tableView_vehicules_clicked(const QModelIndex &index);

private:
    Ui::MainWindow *ui;
    Seance currentSeance;
    Vehicule V; // Instance de Vehicule

    // Méthodes utilitaires
    void refreshTableSeance();
    void clearFieldsSeance();

    void refreshTableVehicule();
    void clearFieldsVehicule();
};

#endif // MAINWINDOW_H
