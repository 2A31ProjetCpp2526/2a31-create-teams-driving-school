#include "mainwindow.h"
#include "seance.h"
#include "vehicule.h"
#include "ui_mainwindow.h"
#include "connection.h"
#include <QWidget>
#include <QLabel>
#include <QMessageBox>
#include <QSqlQuery>
#include <QDebug>
#include <QDate>
#include <QTime>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // Initialisation de la base de données
    Connection conn;
    if (conn.createConnect()) {
        QSqlQuery query;

        // Insertion de données de test pour séances
        query.exec("INSERT INTO SEANCE (ID_SEANCE, IMMATRICULE, ID_CLIENT, ID_MONITEUR, DATE_SEANCE, HEURE_DEBUT, TYPE, APPAREIL, DUREE) "
                   "SELECT 1, '123TU1234', 1, 1, SYSDATE, '08:00', 'code', 'PC', 2 FROM DUAL "
                   "WHERE NOT EXISTS (SELECT 1 FROM SEANCE WHERE ID_SEANCE = 1)");

        query.exec("INSERT INTO SEANCE (ID_SEANCE, IMMATRICULE, ID_CLIENT, ID_MONITEUR, DATE_SEANCE, HEURE_DEBUT, TYPE, APPAREIL, DUREE) "
                   "SELECT 2, '200TU5678', 2, 2, SYSDATE, '10:00', 'conduite', 'Voiture', 1 FROM DUAL "
                   "WHERE NOT EXISTS (SELECT 1 FROM SEANCE WHERE ID_SEANCE = 2)");

        // Insertion de données de test pour véhicules
        // Insertion de données de test pour véhicules
        query.exec("INSERT INTO VEHICULE (IMMATRICULE, MODELE_VEHICULE, TYPE_VEHICULE, TRANSMISSION, KILOMETRAGE, ETAT, DATE_ASSURANCE) "
                   "SELECT '123TU1234', 'Peugeot 208', 'Voiture', 'Manuelle', 15000, 'Disponible', TO_DATE('01/01/2025', 'DD/MM/YYYY') FROM DUAL "
                   "WHERE NOT EXISTS (SELECT 1 FROM VEHICULE WHERE IMMATRICULE = '123TU1234')");

        query.exec("INSERT INTO VEHICULE (IMMATRICULE, MODELE_VEHICULE, TYPE_VEHICULE, TRANSMISSION, KILOMETRAGE, ETAT, DATE_ASSURANCE) "
                   "SELECT '200TU5678', 'Renault Clio', 'Voiture', 'Automatique', 8000, 'En maintenance', TO_DATE('01/06/2024', 'DD/MM/YYYY') FROM DUAL "
                   "WHERE NOT EXISTS (SELECT 1 FROM VEHICULE WHERE IMMATRICULE = '200TU5678')");


        refreshTableSeance();
        refreshTableVehicule();

        QMessageBox::information(this, "Succès", "Base de données initialisée avec succès!");
    } else {
        QMessageBox::critical(this, "Erreur", "Connexion à la base de données échouée!");
    }

    // Connexions pour la navigation entre pages
    connect(ui->seance, &QPushButton::clicked, this, &MainWindow::seanceclick);
    connect(ui->employe, &QPushButton::clicked, this, &MainWindow::employeclick);
    connect(ui->client, &QPushButton::clicked, this, &MainWindow::clientclick);
    connect(ui->vehicule, &QPushButton::clicked, this, &MainWindow::vehiculeclick);
    connect(ui->contrat, &QPushButton::clicked, this, &MainWindow::contratclick);

    // Configuration des pages
    for (int i = 1; i <= 4; ++i) {
        QWidget *page = new QWidget();
        QLabel *label = new QLabel("Page " + QString::number(i) + " - Contenu à ajouter", page);
        label->setGeometry(100, 100, 300, 50);
        ui->stack->addWidget(page);
    }

    ui->stack->setCurrentIndex(0);
}

// ==================== NAVIGATION ====================
void MainWindow::seanceclick() {
    ui->stack->setCurrentIndex(0);
    refreshTableSeance();
}

void MainWindow::vehiculeclick(){
    ui->stack->setCurrentIndex(3);
    refreshTableVehicule();
}

void MainWindow::employeclick() {
    ui->stack->setCurrentIndex(1);
}

void MainWindow::clientclick() {
    ui->stack->setCurrentIndex(2);
}

void MainWindow::contratclick() {
    ui->stack->setCurrentIndex(4);
}

// ==================== GESTION SÉANCES ====================
void MainWindow::refreshTableSeance()
{
    QSqlQueryModel *model = Seance::afficher();
    ui->tableView_seances->setModel(model);
}

void MainWindow::clearFieldsSeance()
{
    ui->lineEdit_id->clear();
    ui->dateEdit_date->setDate(QDate::currentDate());
    ui->timeEdit_heure->setTime(QTime::currentTime());
    ui->lineEdit_duree->clear();
    ui->comboBox_type->setCurrentIndex(0);
    ui->lineEdit_appareil->clear();
    ui->lineEdit_id_client->clear();
    ui->lineEdit_immatricule->clear();
    ui->lineEdit_id_moniteur->clear();
}

void MainWindow::on_pushButton_valider_clicked()
{
    int id = ui->lineEdit_id->text().toInt();
    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();
    int id_client = ui->lineEdit_id_client->text().toInt();
    QString immatricule = ui->lineEdit_immatricule->text();
    int id_moniteur = ui->lineEdit_id_moniteur->text().toInt();

    // Validation des champs
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "ID séance doit être supérieur à 0!");
        return;
    }
    if (duree <= 0) {
        QMessageBox::warning(this, "Attention", "Durée doit être supérieure à 0!");
        return;
    }
    if (appareil.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Appareil ne peut pas être vide!");
        return;
    }
    if (id_client <= 0) {
        QMessageBox::warning(this, "Attention", "ID client doit être supérieur à 0!");
        return;
    }
    if (immatricule.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Immatricule ne peut pas être vide!");
        return;
    }
    if (id_moniteur <= 0) {
        QMessageBox::warning(this, "Attention", "ID moniteur doit être supérieur à 0!");
        return;
    }

    // Vérifier si l'ID existe déjà
    if (Seance::existeDeja(id)) {
        QMessageBox::warning(this, "Attention", "Cet ID existe déjà! Veuillez utiliser un ID différent.");
        return;
    }

    Seance seance(id, date, heure, duree, type, appareil, id_client, immatricule, id_moniteur);

    if (seance.ajouter()) {
        QMessageBox::information(this, "Succès", "Séance ajoutée avec succès!");
        refreshTableSeance();
        clearFieldsSeance();
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de l'ajout!");
    }
}

void MainWindow::on_pushButton_modifier_clicked()
{
    int id = ui->lineEdit_id->text().toInt();
    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner une séance à modifier!");
        return;
    }

    QDate date = ui->dateEdit_date->date();
    QTime heure = ui->timeEdit_heure->time();
    int duree = ui->lineEdit_duree->text().toInt();
    QString type = ui->comboBox_type->currentText();
    QString appareil = ui->lineEdit_appareil->text();
    int id_client = ui->lineEdit_id_client->text().toInt();
    QString immatricule = ui->lineEdit_immatricule->text();
    int id_moniteur = ui->lineEdit_id_moniteur->text().toInt();

    // Validation
    if (duree <= 0 || appareil.isEmpty() || id_client <= 0 || immatricule.isEmpty() || id_moniteur <= 0) {
        QMessageBox::warning(this, "Attention", "Veuillez remplir tous les champs correctement!");
        return;
    }

    Seance seance(id, date, heure, duree, type, appareil, id_client, immatricule, id_moniteur);

    if (seance.modifier()) {
        QMessageBox::information(this, "Succès", "Séance modifiée avec succès!");
        refreshTableSeance();
        clearFieldsSeance();
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de la modification!");
    }
}

void MainWindow::on_pushButton_supprimer_clicked()
{
    int id = ui->lineEdit_id->text().toInt();

    if (id <= 0) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner une séance à supprimer!");
        return;
    }

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation",
                                  "Voulez-vous vraiment supprimer cette séance?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        if (Seance::supprimer(id)) {
            QMessageBox::information(this, "Succès", "Séance supprimée avec succès!");
            refreshTableSeance();
            clearFieldsSeance();
        } else {
            QMessageBox::critical(this, "Erreur", "Erreur lors de la suppression!");
        }
    }
}

void MainWindow::on_pushButton_recherche_clicked()
{
    QString critere = ui->lineEdit_recherche->text();
    QSqlQueryModel *model;

    if (!critere.isEmpty()) {
        model = Seance::rechercher(critere);
        if (model->rowCount() == 0) {
            QMessageBox::information(this, "Recherche", "Aucune séance trouvée pour: " + critere);
        }
    } else {
        model = Seance::afficher();
    }

    ui->tableView_seances->setModel(model);
}

void MainWindow::on_tableView_seances_clicked(const QModelIndex &index)
{
    int id = index.sibling(index.row(), 0).data().toInt();
    QString immatricule = index.sibling(index.row(), 1).data().toString();
    int id_client = index.sibling(index.row(), 2).data().toInt();
    int id_moniteur = index.sibling(index.row(), 3).data().toInt();
    QDate date = index.sibling(index.row(), 4).data().toDate();
    QString heureStr = index.sibling(index.row(), 5).data().toString();
    QString type = index.sibling(index.row(), 6).data().toString();
    QString appareil = index.sibling(index.row(), 7).data().toString();
    int duree = index.sibling(index.row(), 8).data().toInt();

    // Conversion de l'heure string vers QTime
    QTime heure = QTime::fromString(heureStr, "HH:mm");
    if (!heure.isValid()) {
        heure = QTime::fromString(heureStr, "hh:mm");
    }

    ui->lineEdit_id->setText(QString::number(id));
    ui->dateEdit_date->setDate(date);
    ui->timeEdit_heure->setTime(heure);
    ui->lineEdit_duree->setText(QString::number(duree));

    int indexType = ui->comboBox_type->findText(type);
    if (indexType != -1) {
        ui->comboBox_type->setCurrentIndex(indexType);
    } else {
        ui->comboBox_type->setCurrentIndex(0);
    }

    ui->lineEdit_appareil->setText(appareil);
    ui->lineEdit_id_client->setText(QString::number(id_client));
    ui->lineEdit_immatricule->setText(immatricule);
    ui->lineEdit_id_moniteur->setText(QString::number(id_moniteur));
}

// ==================== GESTION VÉHICULES ====================
void MainWindow::refreshTableVehicule()
{
    QSqlQueryModel *model = V.afficher();
    ui->tableView_vehicules->setModel(model);
}

void MainWindow::clearFieldsVehicule()
{
    ui->lineEdit_immatricule->clear();
    ui->lineEdit_modele->clear();
    ui->comboBox_type_2->setCurrentIndex(0);
    ui->comboBox_transmission->setCurrentIndex(0);
    ui->comboBox_etat->setCurrentIndex(0);
    ui->dateEdit_assurance->setDate(QDate::currentDate());
}

void MainWindow::on_pushButton_validervehicule_clicked()
{
    QString imm = ui->lineEdit_immatricule_2->text().trimmed();
    QString mod = ui->lineEdit_modele->text().trimmed();
    QString typ = ui->comboBox_type_2->currentText();
    QString trans = ui->comboBox_transmission->currentText();
    QString et = ui->comboBox_etat->currentText();
    QDate date = ui->dateEdit_assurance->date();

    // Validation
    if (imm.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Immatriculation ne peut pas être vide!");
        return;
    }
    if (mod.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Modèle ne peut pas être vide!");
        return;
    }

    Vehicule v(imm, mod, typ, trans, et, date);
    bool test = v.ajouter();

    if (test) {
        QMessageBox::information(this, "Succès", "✓ Véhicule ajouté avec succès.");
        refreshTableVehicule();
        clearFieldsVehicule();
    } else {
        QMessageBox::critical(this, "Erreur", "✗ Échec de l'ajout. Vérifiez que l'immatriculation n'existe pas déjà.");
    }
}

void MainWindow::on_pushButton_supprimervehicule_clicked()
{
    QString id = ui->lineEdit_immatricule->text().trimmed();

    if (id.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner un véhicule à supprimer!");
        return;
    }

    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "Confirmation",
                                  "Voulez-vous vraiment supprimer ce véhicule?",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes) {
        bool test = V.supprimer(id);
        if (test) {
            QMessageBox::information(this, "Succès", "Véhicule supprimé avec succès ✓");
            refreshTableVehicule();
            clearFieldsVehicule();
        } else {
            QMessageBox::critical(this, "Erreur", "Échec de la suppression ✗");
        }
    }
}

void MainWindow::on_pushButton_modifiervehicule_clicked()
{
    QString id = ui->lineEdit_immatricule->text().trimmed();
    QString mod = ui->lineEdit_modele->text().trimmed();
    QString typ = ui->comboBox_type_2->currentText();
    QString trans = ui->comboBox_transmission->currentText();
    QString et = ui->comboBox_etat->currentText();
    QDate date = ui->dateEdit_assurance->date();

    // Validation
    if (id.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Veuillez sélectionner un véhicule à modifier!");
        return;
    }
    if (mod.isEmpty()) {
        QMessageBox::warning(this, "Attention", "Modèle ne peut pas être vide!");
        return;
    }

    Vehicule v(id, mod, typ, trans, et, date);
    bool test = v.modifier(id);

    if (test) {
        QMessageBox::information(this, "Succès", "Modification effectuée ✓");
        refreshTableVehicule();
        clearFieldsVehicule();
    } else {
        QMessageBox::critical(this, "Erreur", "Échec de la modification ✗");
    }
}

void MainWindow::on_tableView_vehicules_clicked(const QModelIndex &index)
{
    QString immatricule = index.sibling(index.row(), 0).data().toString();
    QString modele      = index.sibling(index.row(), 1).data().toString();
    QString type        = index.sibling(index.row(), 2).data().toString();
    QString transmission= index.sibling(index.row(), 3).data().toString();
    QString etat        = index.sibling(index.row(), 4).data().toString();

    // La date est maintenant au format DD/MM/YYYY depuis TO_CHAR
    QString dateStr = index.sibling(index.row(), 5).data().toString();
    QDate dateAssurance = QDate::fromString(dateStr, "dd/MM/yyyy");

    if (!dateAssurance.isValid()) {
        dateAssurance = QDate::currentDate();
    }

    ui->lineEdit_immatricule->setText(immatricule);
    ui->lineEdit_modele->setText(modele);

    int indexType = ui->comboBox_type_2->findText(type);
    ui->comboBox_type_2->setCurrentIndex(indexType != -1 ? indexType : 0);

    int indexTrans = ui->comboBox_transmission->findText(transmission);
    ui->comboBox_transmission->setCurrentIndex(indexTrans != -1 ? indexTrans : 0);

    int indexEtat = ui->comboBox_etat->findText(etat);
    ui->comboBox_etat->setCurrentIndex(indexEtat != -1 ? indexEtat : 0);

    ui->dateEdit_assurance->setDate(dateAssurance);
}

MainWindow::~MainWindow()
{
    delete ui;
}
