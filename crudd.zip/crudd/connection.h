#ifndef CONNECTION_H
#define CONNECTION_H
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QDebug>

class Connection
{
private:
    QSqlDatabase db;

public:
    Connection();
    bool createConnect();   // ✅ majuscule cohérente
    void closeConnect();
};

#endif // CONNECTION_H
